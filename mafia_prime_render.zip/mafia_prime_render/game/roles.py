from dataclasses import dataclass
@dataclass(frozen=True)
class Role: name:str; team:str; action:str
ROLES={
'DON':Role('Don','mafia','kill'),'MAFIA':Role('Mafia','mafia','kill'),'COMMISSIONER':Role('Komissar','citizen','check'),'DOCTOR':Role('Doktor','citizen','heal'),
'WIZARD':Role('Afsungar','citizen','protect'),'JUDGE':Role('Sudya','citizen','judge'),'CHAIRMAN':Role('Rais','citizen','chairman'),'MASK':Role('Niqobchi','independent','mask'),'DETECTIVE':Role('Detektiv','citizen','check'),'CITIZEN':Role('Fuqaro','citizen','none')}

def role_set(n):
    # deterministic scaling to 50; mafia count grows gradually, specials remain meaningful
    mafia=max(1,min(12,n//4)); roles=['DON']+['MAFIA']*(mafia-1)
    specials=['COMMISSIONER','DOCTOR','DETECTIVE','WIZARD','JUDGE','CHAIRMAN','MASK']
    for i in range(min(len(specials),max(0,n-len(roles)))): roles.append(specials[i])
    roles += ['CITIZEN']*(n-len(roles));return roles
