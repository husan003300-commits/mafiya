import random
from collections import Counter
from datetime import datetime,timezone,timedelta
from sqlalchemy import select,delete
from database.db import SessionLocal
from database.models import Game,GamePlayer,GameAction,Vote,User
from game.roles import role_set,ROLES
class GameEngine:
 def create_lobby(self,group_id,max_players=50,join_minutes=2):
  with SessionLocal() as s:
   g=s.scalar(select(Game).where(Game.group_id==group_id,Game.status.in_(['lobby','running'])))
   if g:return g
   g=Game(group_id=group_id,status='lobby',phase='lobby',join_deadline=datetime.now(timezone.utc)+timedelta(minutes=join_minutes));s.add(g);s.commit();s.refresh(g);return g
 def players(self,gid):
  with SessionLocal() as s:return list(s.scalars(select(GamePlayer).where(GamePlayer.game_id==gid)).all())
 def alive(self,gid):
  with SessionLocal() as s:return list(s.scalars(select(GamePlayer).where(GamePlayer.game_id==gid,GamePlayer.alive==True)).all())
 def add_player(self,gid,uid,name,max_players):
  with SessionLocal() as s:
   g=s.get(Game,gid)
   if not g or g.status!='lobby':return False,'Lobby yopilgan'
   if g.join_deadline and datetime.now(timezone.utc)>g.join_deadline:return False,'⏰ Qo‘shilish vaqti tugagan'
   if s.scalar(select(GamePlayer).where(GamePlayer.game_id==gid,GamePlayer.user_id==uid)):return False,'Siz allaqachon qo‘shilgansiz'
   count=len(s.scalars(select(GamePlayer).where(GamePlayer.game_id==gid)).all())
   if count>=min(50,max(4,max_players)):return False,'O‘yin 50/50 ga to‘ldi'
   s.add(GamePlayer(game_id=gid,user_id=uid,display_name=name));s.commit();return True,'OK'
 def remove_player(self,gid,uid):
  with SessionLocal() as s:
   p=s.scalar(select(GamePlayer).where(GamePlayer.game_id==gid,GamePlayer.user_id==uid))
   if not p:return False
   s.delete(p);s.commit();return True
 def start(self,gid):
  with SessionLocal() as s:
   g=s.get(Game,gid);ps=list(s.scalars(select(GamePlayer).where(GamePlayer.game_id==gid)).all())
   if not g or len(ps)<4:return None,'Kamida 4 o‘yinchi kerak'
   roles=role_set(len(ps));random.shuffle(roles)
   for p,key in zip(ps,roles): p.role_key=key;p.role=ROLES[key].name;p.team=ROLES[key].team;p.alive=True;p.action_used=False
   g.status='running';g.phase='night';g.day_number=1;s.commit();return ps,'OK'
 def get_player(self,gid,uid):
  with SessionLocal() as s:return s.scalar(select(GamePlayer).where(GamePlayer.game_id==gid,GamePlayer.user_id==uid))
 def set_phase(self,gid,phase):
  with SessionLocal() as s:g=s.get(Game,gid);g.phase=phase;s.commit() if g else None
 def action(self,gid,actor,target,action,phase,day):
  with SessionLocal() as s:
   g=s.get(Game,gid);a=s.scalar(select(GamePlayer).where(GamePlayer.game_id==gid,GamePlayer.user_id==actor));t=s.scalar(select(GamePlayer).where(GamePlayer.game_id==gid,GamePlayer.user_id==target))
   if not g or g.status!='running' or not a or not t or not a.alive or not t.alive:return False,'Amal bajarilmaydi'
   if g.phase!=phase:return False,'Hozir bu amal vaqti emas'
   s.add(GameAction(game_id=gid,actor_id=actor,target_id=target,action=action,day=day,phase=phase));s.commit();return True,'OK'
 def resolve_night(self,gid):
  with SessionLocal() as s:
   g=s.get(Game,gid);ps=list(s.scalars(select(GamePlayer).where(GamePlayer.game_id==gid,GamePlayer.alive==True)).all());acts=list(s.scalars(select(GameAction).where(GameAction.game_id==gid,GameAction.day==g.day_number,GameAction.phase=='night')).all())
   kills=[a.target_id for a in acts if a.action=='kill']; heals={a.target_id for a in acts if a.action=='heal'}; deaths=[]
   for uid in kills:
    if uid not in heals:
     p=next((x for x in ps if x.user_id==uid),None)
     if p and p.alive:p.alive=False;deaths.append(p)
   g.phase='day';s.commit();return deaths
 def cast_vote(self,gid,voter,target,kind='eliminate'):
  with SessionLocal() as s:
   g=s.get(Game,gid);v=s.scalar(select(GamePlayer).where(GamePlayer.game_id==gid,GamePlayer.user_id==voter));t=s.scalar(select(GamePlayer).where(GamePlayer.game_id==gid,GamePlayer.user_id==target))
   if not g or g.phase!='vote' or not v or not t or not v.alive or not t.alive:return False,'Ovoz berish mumkin emas'
   old=s.scalar(select(Vote).where(Vote.game_id==gid,Vote.voter_id==voter,Vote.kind==kind,Vote.day==g.day_number))
   if old:old.target_id=target
   else:s.add(Vote(game_id=gid,voter_id=voter,target_id=target,kind=kind,day=g.day_number))
   s.commit();return True,'OK'
 def resolve_vote(self,gid,kind='eliminate'):
  with SessionLocal() as s:
   g=s.get(Game,gid);votes=list(s.scalars(select(Vote).where(Vote.game_id==gid,Vote.kind==kind,Vote.day==g.day_number)).all());c=Counter(v.target_id for v in votes);maxv=max(c.values(),default=0);targets=[k for k,v in c.items() if v==maxv];
   if len(targets)!=1:return None,'tie'
   p=s.scalar(select(GamePlayer).where(GamePlayer.game_id==gid,GamePlayer.user_id==targets[0]));
   if p:p.alive=False
   s.commit();return p,'ok' if p else 'none'
 def winner(self,gid):
  ps=self.alive(gid);mafia=sum(p.team=='mafia' for p in ps);other=len(ps)-mafia
  return 'mafia' if mafia and mafia>=other else ('citizen' if mafia==0 else None)
