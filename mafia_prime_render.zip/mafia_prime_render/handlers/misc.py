from telegram import Update
from telegram.ext import ContextTypes
from sqlalchemy import select
from database.db import SessionLocal
from database.models import User,Game
from config import settings
async def top(update,context):
 with SessionLocal() as s:users=list(s.scalars(select(User).order_by(User.xp.desc()).limit(10)).all())
 await update.effective_message.reply_text('🏆 TOP 10\n\n'+'\n'.join(f'{i}. {u.name} — ⭐ {u.xp} XP' for i,u in enumerate(users,1)) or 'Bo‘sh')
async def help_cmd(update,context):
 await update.effective_message.reply_text('📖 MAFIA PRIME\n\n/start /profile /balance /bonus /game /startgame /cancelgame /settings /top\n/pay @user amount money|diamond\n/owner /admin /grant_pro /grant_hero /give /add_admin /setperm\n/exchange N — join vaqtini sozlash')
async def exchange(update,context):
 if not context.args:return await update.effective_message.reply_text(f'⏱ Join default: {settings.join_time_minutes} min\n/setjoin N')
 try:n=max(1,min(999999,int(context.args[0])))
 except:return await update.effective_message.reply_text('❌ Son kiriting.')
 if update.effective_chat.type not in ('group','supergroup'):return
 m=await update.effective_chat.get_member(update.effective_user.id)
 if m.status not in ('administrator','creator'):return await update.effective_message.reply_text('❌ Admin kerak.')
 from database.db import SessionLocal
 from database.models import GroupSetting
 with SessionLocal() as s:
  st=s.get(GroupSetting,update.effective_chat.id)
  if not st:st=GroupSetting(group_id=update.effective_chat.id);s.add(st)
  st.join_minutes=n;s.commit()
 await update.effective_message.reply_text(f'✅ Join vaqti: {n} daqiqa')
