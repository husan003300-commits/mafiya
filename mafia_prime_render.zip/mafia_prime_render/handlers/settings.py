from telegram import Update,InlineKeyboardButton,InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database.db import SessionLocal
from database.models import Group,GroupSetting
async def settings_cmd(update,context):
 if update.effective_chat.type not in ('group','supergroup'):return await update.effective_message.reply_text('⚙️ /settings guruhda ishlaydi.')
 m=await update.effective_chat.get_member(update.effective_user.id)
 if m.status not in ('administrator','creator'):return await update.effective_message.reply_text('❌ Guruh admini kerak.')
 with SessionLocal() as s:
  g=s.get(Group,update.effective_chat.id)
  if not g:g=Group(id=update.effective_chat.id,title=update.effective_chat.title);s.add(g)
  st=s.get(GroupSetting,g.id)
  if not st:st=GroupSetting(group_id=g.id);s.add(st)
  s.commit()
 text=f'⚙️ GROUP SETTINGS\n\n🎮 Game: {"ON" if st.game_enabled else "OFF"}\n💑 Para: {"ON" if st.para_enabled else "OFF"}\n💰 Economy: {"ON" if st.economy_enabled else "OFF"}\n🎁 Bonus: {"ON" if st.bonus_enabled else "OFF"}\n🌟 PRO: {"ON" if st.pro_enabled else "OFF"}\n🦸 HERO: {"ON" if st.hero_enabled else "OFF"}\n👥 Max players: {st.max_players}\n⏱ Join: {st.join_minutes} min\n🎨 Style: {st.button_style}'
 await update.effective_message.reply_text(text,reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('🎮 Game ON/OFF',callback_data='gs:game')],[InlineKeyboardButton('👥 Max 50',callback_data='gs:max50')],[InlineKeyboardButton('🎨 Primary',callback_data='gs:primary'),InlineKeyboardButton('✅ Success',callback_data='gs:success'),InlineKeyboardButton('❌ Danger',callback_data='gs:danger')]]))
async def settings_callback(update,context):
 q=update.callback_query
 if not q.data.startswith('gs:'):return False
 m=await update.effective_chat.get_member(q.from_user.id)
 if m.status not in ('administrator','creator'):await q.answer('Admin kerak',show_alert=True);return True
 key=q.data.split(':')[1]
 with SessionLocal() as s:
  st=s.get(GroupSetting,update.effective_chat.id)
  if not st:st=GroupSetting(group_id=update.effective_chat.id);s.add(st)
  if key=='game':st.game_enabled=not st.game_enabled
  elif key=='max50':st.max_players=50
  elif key in ('primary','success','danger'):st.button_style=key
  s.commit()
 await q.answer('Saqlandi');return True
