from telegram import Update
from telegram.ext import ContextTypes
from sqlalchemy import select
from database.db import SessionLocal
from database.models import User
from database.users import get_or_create
from economy.service import transfer
async def economy(update,context):
 u=get_or_create(update.effective_user);await update.effective_message.reply_text(f'💰 BALANCE\n\n💵 Money: {u.money:,}\n💎 Diamonds: {u.diamonds:,}\n⭐ XP: {u.xp}\n🌟 PRO: {"ACTIVE" if u.pro_until else "NO"}\n🦸 HERO: {"ACTIVE" if u.hero_until else "NO"}')
async def pay(update,context):
 if len(context.args)<3:return await update.effective_message.reply_text('/pay @username 100 money')
 target,amount_s,cur=context.args[:3]
 try:amount=int(amount_s)
 except:return await update.effective_message.reply_text('❌ Amount noto‘g‘ri')
 with SessionLocal() as s:to=s.scalar(select(User).where(User.username==target.lstrip('@')));tid=to.id if to else None
 if not tid:return await update.effective_message.reply_text('❌ User topilmadi')
 ok,msg=transfer(update.effective_user.id,tid,'diamonds' if cur.startswith('dia') else 'money',amount);await update.effective_message.reply_text('✅ Yuborildi.' if ok else '❌ '+msg)
