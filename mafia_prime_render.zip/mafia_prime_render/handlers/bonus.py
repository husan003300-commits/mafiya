from datetime import datetime,timezone,timedelta
from telegram import Update
from telegram.ext import ContextTypes
from database.users import get_or_create
from config import settings
async def bonus(update,context):
 u=get_or_create(update.effective_user);now=datetime.now(timezone.utc)
 if u.last_bonus and u.last_bonus+timedelta(hours=24)>now:return await update.effective_message.reply_text('⏳ Daily bonus 24 soatdan keyin tayyor.')
 from database.db import SessionLocal
 with SessionLocal() as s:
  x=s.get(type(u),u.id);x.money+=settings.daily_money;x.diamonds+=settings.daily_diamonds;x.last_bonus=now;s.commit()
 await update.effective_message.reply_text(f'🎁 BONUS\n\n💵 +{settings.daily_money}\n💎 +{settings.daily_diamonds}')
