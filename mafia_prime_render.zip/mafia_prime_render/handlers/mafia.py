from datetime import datetime,timezone
from telegram import Update,InlineKeyboardButton,InlineKeyboardMarkup
from telegram.ext import ContextTypes
from sqlalchemy import select
from database.db import SessionLocal
from database.models import Game,GamePlayer,Group,GroupSetting,User
from database.users import get_or_create
from game.engine import GameEngine
from config import settings
engine=GameEngine()
def name(u):return ('@'+u.username) if u.username else u.full_name
def lobby_text(gid):
 ps=engine.players(gid);g=next((x for x in []),None)
 with SessionLocal() as s: gg=s.get(Game,gid)
 left='—'
 if gg and gg.join_deadline:left=max(0,int((gg.join_deadline-datetime.now(timezone.utc)).total_seconds()))//60+1
 return '🎭 MAFIA PRIME\n\n🎮 O‘yinga qo‘shilish\n\n👥 O‘yinchilar: '+str(len(ps))+'/50\n⏳ Qolgan vaqt: '+str(left)+' min\n\n'+'\n'.join(f'{i}. 👤 {p.display_name}' for i,p in enumerate(ps,1))
def lobby_kb(gid):return InlineKeyboardMarkup([[InlineKeyboardButton('🎮 Qo‘shilish',callback_data=f'join:{gid}'),InlineKeyboardButton('❌ Chiqish',callback_data=f'leave:{gid}')],[InlineKeyboardButton('👥 Ro‘yxat',callback_data=f'players:{gid}'),InlineKeyboardButton('▶️ Start',callback_data=f'start:{gid}')]])
async def ensure_group(chat):
 with SessionLocal() as s:
  g=s.get(Group,chat.id)
  if not g:g=Group(id=chat.id,title=chat.title or 'Group');s.add(g);s.add(GroupSetting(group_id=chat.id));s.commit()
async def game(update,context):
 if update.effective_chat.type not in ('group','supergroup'):return await update.effective_message.reply_text('❌ /game guruhda ishlaydi.')
 await ensure_group(update.effective_chat)
 with SessionLocal() as s:
  st=s.get(GroupSetting,update.effective_chat.id)
  if not st.game_enabled:return await update.effective_message.reply_text('❌ O‘yin o‘chirilgan.')
 g=engine.create_lobby(update.effective_chat.id,min(50,max(4,st.max_players)),st.join_minutes)
 msg=await update.effective_message.reply_text(lobby_text(g.id),reply_markup=lobby_kb(g.id));
 with SessionLocal() as s:gg=s.get(Game,g.id);gg.lobby_message_id=msg.message_id;gg.pin_message_id=msg.message_id;s.commit()
 try:await context.bot.pin_chat_message(update.effective_chat.id,msg.message_id,disable_notification=True)
 except:pass
async def start_game(context,gid,chat_id):
 ps,msg=engine.start(gid)
 if not ps:return False,msg
 await context.bot.send_message(chat_id,f'🎭 O‘YIN BOSHLANDI!\n👥 {len(ps)} player\n🌙 1-TUN boshlandi.')
 for p in ps:
  try:await context.bot.send_message(p.user_id,f'🎭 SIZNING ROLINGIZ\n\n{p.role}\n🎯 Jamoa: {p.team}\n\n🌙 Tundagi harakatlar keyin tugmalar orqali beriladi.')
  except:pass
 return True,'OK'
async def startgame(update,context):
 if update.effective_chat.type not in ('group','supergroup'):return
 m=await update.effective_chat.get_member(update.effective_user.id)
 if m.status not in ('administrator','creator'):return await update.effective_message.reply_text('❌ Faqat guruh admini.')
 with SessionLocal() as s:g=s.scalar(select(Game).where(Game.group_id==update.effective_chat.id,Game.status=='lobby'))
 if not g:return await update.effective_message.reply_text('❌ Aktiv lobby yo‘q.')
 ok,msg=await start_game(context,g.id,update.effective_chat.id);await update.effective_message.reply_text('✅ Boshladi.' if ok else '❌ '+msg)
 if ok: await send_night(context,g.id,update.effective_chat.id)
async def cancelgame(update,context):
 with SessionLocal() as s:g=s.scalar(select(Game).where(Game.group_id==update.effective_chat.id,Game.status=='lobby')); 
 if g:g.status='cancelled';s.commit()
 await update.effective_message.reply_text('❌ Lobby bekor qilindi.')
async def callback(update,context):
 q=update.callback_query;await q.answer();parts=q.data.split(':');action=parts[0];gid=int(parts[1]);uid=q.from_user.id
 if action=='join':
  ok,msg=engine.add_player(gid,uid,name(q.from_user),50)
  if not ok:return await q.answer(msg,show_alert=True)
 elif action=='leave':engine.remove_player(gid,uid)
 elif action=='start':
  chat=update.effective_chat
  m=await chat.get_member(uid)
  if m.status not in ('administrator','creator'):return await q.answer('Faqat admin.',show_alert=True)
  ok,msg=await start_game(context,gid,chat.id)
  if not ok:return await q.answer(msg,show_alert=True)
  await q.answer('🎭 O‘yin boshlandi.')
  await send_night(context,gid,chat.id)
  return
 elif action=='players':return await q.answer('\n'.join(p.display_name for p in engine.players(gid)) or 'Bo‘sh',show_alert=True)
 elif action=='action':
  _,_,act,target=parts
  p=engine.get_player(gid,uid)
  if not p or not p.alive:return await q.answer('❌ Siz tirik emassiz.',show_alert=True)
  allowed={'DON':'kill','MAFIA':'kill','DOCTOR':'heal','WIZARD':'heal','COMMISSIONER':'check','DETECTIVE':'check'}
  if allowed.get(p.role_key)!=act:return await q.answer('❌ Bu amal sizga tegishli emas.',show_alert=True)
  
  with SessionLocal() as ss: gg=ss.get(Game,gid); day=gg.day_number if gg else 1
  ok,msg=engine.action(gid,uid,int(target),act,'night',day)
  await q.answer('✅ Amal qabul qilindi.' if ok else '❌ '+msg,show_alert=True)
  return
 elif action=='vote':
  ok,msg=engine.cast_vote(gid,uid,int(parts[2]));await q.answer('✅ Ovoz qabul qilindi.' if ok else '❌ '+msg,show_alert=True)
  return
 try:await q.edit_message_text(lobby_text(gid),reply_markup=lobby_kb(gid))
 except:pass

async def send_night(context,gid,chat_id):
 with SessionLocal() as s:
  g=s.get(Game,gid);ps=list(s.scalars(select(GamePlayer).where(GamePlayer.game_id==gid,GamePlayer.alive==True)).all())
 if not g or g.status!='running':return
 engine.set_phase(gid,'night')
 await context.bot.send_message(chat_id,f'🌙 {g.day_number}-TUN\n\nRollar o‘z harakatini PM orqali tanlaydi.')
 for p in ps:
  if p.role_key in ('DON','MAFIA','COMMISSIONER','DOCTOR','DETECTIVE','WIZARD'):
   buttons=[]
   for t in ps:
    if t.user_id==p.user_id:continue
    label=f'🎯 {t.display_name[:20]}'
    action='kill' if p.role_key in ('DON','MAFIA') else ('heal' if p.role_key in ('DOCTOR','WIZARD') else 'check')
    buttons.append([InlineKeyboardButton(label,callback_data=f'action:{gid}:{action}:{t.user_id}')])
   try:await context.bot.send_message(p.user_id,f'🌙 TUN\n🎭 Rol: {p.role}\n\nNishonni tanlang:',reply_markup=InlineKeyboardMarkup(buttons[:49]))
   except:pass
 context.job_queue.run_once(night_end,settings.night_seconds,data={'gid':gid,'chat_id':chat_id})
async def night_end(context):
 d=context.job.data;gid=d['gid'];chat_id=d['chat_id'];deaths=engine.resolve_night(gid)
 if deaths:
  names=', '.join(x.display_name for x in deaths);await context.bot.send_message(chat_id,f'☀️ TONG\n\n🌑 Kechasi o‘yindan chiqdi: {names}')
 else:await context.bot.send_message(chat_id,'☀️ TONG\n\n🌙 Kechasi hech kim o‘yindan chiqmagan.')
 with SessionLocal() as s:g=s.get(Game,gid)
 if not g:return
 w=engine.winner(gid)
 if w:return await finish_game(context,gid,chat_id,w)
 engine.set_phase(gid,'discussion');await context.bot.send_message(chat_id,'🗣 MUHOKAMA\n\nGaplashish vaqti boshlandi.')
 context.job_queue.run_once(start_vote,settings.discussion_seconds,data={'gid':gid,'chat_id':chat_id})
async def start_vote(context):
 gid=context.job.data['gid'];chat_id=context.job.data['chat_id'];engine.set_phase(gid,'vote');ps=engine.alive(gid)
 buttons=[]
 for t in ps:buttons.append([InlineKeyboardButton(f'🗳 {t.display_name[:24]}',callback_data=f'vote:{gid}:{t.user_id}')])
 await context.bot.send_message(chat_id,'🗳 OVOZ BERISH\n\nKim chiqarilsin?',reply_markup=InlineKeyboardMarkup(buttons[:49]))
 context.job_queue.run_once(end_vote,settings.vote_seconds,data={'gid':gid,'chat_id':chat_id})
async def end_vote(context):
 gid=context.job.data['gid'];chat_id=context.job.data['chat_id'];p,result=engine.resolve_vote(gid)
 if result=='tie':await context.bot.send_message(chat_id,'⚖️ Ovozlar teng. Hech kim chiqarilmadi.')
 elif p:await context.bot.send_message(chat_id,f'⚖️ Ovoz natijasi: {p.display_name} o‘yindan chiqarildi.')
 w=engine.winner(gid)
 if w:return await finish_game(context,gid,chat_id,w)
 with SessionLocal() as s:g=s.get(Game,gid);g.day_number+=1;s.commit()
 await send_night(context,gid,chat_id)
async def finish_game(context,gid,chat_id,winner):
 with SessionLocal() as s:
  g=s.get(Game,gid);g.status='finished';g.phase='game_over';g.winner=winner;ps=list(s.scalars(select(GamePlayer).where(GamePlayer.game_id==gid)).all())
  for p in ps:
   u=s.get(User,p.user_id)
   if u:
    u.games+=1
    if (winner=='mafia' and p.team=='mafia') or (winner=='citizen' and p.team!='mafia'):u.wins+=1;u.xp+=100
    else:u.losses+=1;u.xp+=20
  s.commit()
 await context.bot.send_message(chat_id,f'🏆 O‘YIN TUGADI!\n\nG‘olib jamoa: {winner.upper()}')
