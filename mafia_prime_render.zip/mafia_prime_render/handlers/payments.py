from telegram import Update,LabeledPrice
from telegram.ext import ContextTypes
from database.users import grant_status
async def buy_pro(update,context):
 await update.effective_message.reply_invoice(title='🌟 PRO — 30 kun',description='Mafia Prime PRO status, 30 kun.',payload=f'pro30:{update.effective_user.id}',currency='XTR',prices=[LabeledPrice('PRO 30 kun',10)])
async def buy_diamonds(update,context):
 await update.effective_message.reply_invoice(title='💎 150 Diamonds',description='Mafia Prime Diamonds.',payload=f'diamonds150:{update.effective_user.id}',currency='XTR',prices=[LabeledPrice('150 Diamonds',15)])
async def precheckout(update,context):await update.pre_checkout_query.answer(ok=True)
async def successful_payment(update,context):
 p=update.effective_message.successful_payment
 payload=p.invoice_payload
 try:
  kind,uid=payload.split(':',1);uid=int(uid)
 except:return
 if uid!=update.effective_user.id:return
 if kind=='pro30':grant_status(uid,'pro',30);await update.effective_message.reply_text('✅ To‘lov qabul qilindi. 🌟 PRO 30 kunga faollashtirildi.')
 elif kind=='diamonds150':
  from database.users import add_balance
  add_balance(uid,'diamonds',150,'Telegram Stars purchase');await update.effective_message.reply_text('✅ 150 💎 Diamonds hisobingizga qo‘shildi.')
