from datetime import datetime,timezone
from telegram import Update
from telegram.ext import ContextTypes
from database.users import get_or_create
def active(x):return bool(x and x>datetime.now(timezone.utc))
async def profile(update,context):
 u=get_or_create(update.effective_user);await update.effective_message.reply_text(f'👤 PROFILE\n\n{u.name}\n@{u.username or "-"}\n\n💵 {u.money:,}\n💎 {u.diamonds:,}\n⭐ XP {u.xp}\n🏆 Level {u.level}\n🎮 Games {u.games}\n🥇 Wins {u.wins}\n\n🌟 PRO: {"ACTIVE" if active(u.pro_until) else "NO"}\n🦸 HERO: {"ACTIVE" if active(u.hero_until) else "NO"}')
