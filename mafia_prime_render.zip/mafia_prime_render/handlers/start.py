from telegram import Update,InlineKeyboardButton,InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database.users import get_or_create
async def start(update,context):
 get_or_create(update.effective_user)
 await update.effective_message.reply_text('🎭 MAFIA PRIME\n\nXush kelibsiz!\n\n🎮 /game — Mafia\n👤 /profile — profil\n💰 /balance — balans\n🎁 /bonus — bonus\n🏆 /top — TOP\n📖 /help — yordam',reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('🎮 O‘yin',callback_data='noop')],[InlineKeyboardButton('👤 Profil',callback_data='noop')]]))
