import json
from datetime import datetime,timezone
from telegram import Update,InlineKeyboardButton,InlineKeyboardMarkup
from telegram.ext import ContextTypes
from sqlalchemy import select,func
from database.db import SessionLocal
from database.models import Admin,User,Group,Game,AuditLog,CustomRole,CustomEmoji
from database.users import grant_status,add_balance
from config import settings

def is_owner(uid): return uid==settings.owner_id
def admin_row(uid):
 with SessionLocal() as s:return s.get(Admin,uid)
def has_perm(uid,perm):
 if is_owner(uid): return True
 a=admin_row(uid)
 if not a:return False
 if a.level=='superadmin':return True
 try:return bool(json.loads(a.permissions or '{}').get(perm,False))
 except:return False
async def owner(update,context):
 if not is_owner(update.effective_user.id):return await update.effective_message.reply_text('❌ Owner only.')
 with SessionLocal() as s:
  u=s.scalar(select(func.count(User.id)));g=s.scalar(select(func.count(Group.id)));games=s.scalar(select(func.count(Game.id)));pro=s.scalar(select(func.count(User.id)).where(User.pro_until>datetime.now(timezone.utc)))
 await update.effective_message.reply_text(f'👑 OWNER PANEL\n\n👤 Users: {u}\n👥 Groups: {g}\n🎮 Games: {games}\n🌟 PRO: {pro}\n👥 Max players: 50\n\n/add_admin ID level\n/grant_pro ID days\n/grant_hero ID days\n/give ID money|diamonds amount\n/setperm ID permission on|off\n/customemoji key value\n/role_create Name|team|action|uses|target|win')
async def admin(update,context):
 if not has_perm(update.effective_user.id,'panel'):return await update.effective_message.reply_text('❌ Ruxsat yo‘q.')
 await update.effective_message.reply_text('👑 ADMIN PANEL\n\n👤 Users\n👥 Groups\n🎮 Games\n💰 Economy\n🌟 PRO\n🦸 HERO\n🎨 Emoji/Style\n📢 Broadcast\n📊 Statistics\n⚙️ Settings\n\nBuyruqlar /owner orqali.')
async def add_admin(update,context):
 if not is_owner(update.effective_user.id) or len(context.args)<2:return
 uid=int(context.args[0]);level=context.args[1].lower()
 with SessionLocal() as s:s.merge(Admin(user_id=uid,level=level,permissions=json.dumps({'panel':True})));s.add(AuditLog(actor_id=update.effective_user.id,action='add_admin',target=str(uid)));s.commit()
 await update.effective_message.reply_text('✅ Admin qo‘shildi.')
async def setperm(update,context):
 if not is_owner(update.effective_user.id) or len(context.args)<3:return
 uid=int(context.args[0]);perm=context.args[1];value=context.args[2].lower() in ('on','1','yes','true')
 with SessionLocal() as s:
  a=s.get(Admin,uid)
  if not a:return await update.effective_message.reply_text('❌ Admin topilmadi.')
  p=json.loads(a.permissions or '{}');p[perm]=value;a.permissions=json.dumps(p);s.commit()
 await update.effective_message.reply_text(f'✅ {perm}: {"ON" if value else "OFF"}')
async def grant(update,context):
 if not has_perm(update.effective_user.id,'pro') and not has_perm(update.effective_user.id,'hero'):return
 if len(context.args)<2:return await update.effective_message.reply_text('/grant_pro ID days yoki /grant_hero ID days')
 uid=int(context.args[0]);days=int(context.args[1]);status='hero' if 'hero' in update.message.text.split()[0] else 'pro'
 if grant_status(uid,status,days):
  try:await context.bot.send_message(uid,f'🎉 Sizga {status.upper()} status berildi. Muddat: {days} kun.')
  except:pass
  await update.effective_message.reply_text(f'✅ {status.upper()} berildi: {uid} / {days} kun')
async def give(update,context):
 if not is_owner(update.effective_user.id) or len(context.args)<3:return
 uid=int(context.args[0]);cur='diamonds' if context.args[1].lower().startswith('dia') else 'money';amt=int(context.args[2]);ok=add_balance(uid,cur,amt,'owner grant');await update.effective_message.reply_text('✅ Berildi.' if ok else '❌ Xato.')
async def customemoji(update,context):
 if not is_owner(update.effective_user.id) or len(context.args)<2:return
 key=context.args[0];value=' '.join(context.args[1:])
 with SessionLocal() as s:
  row=s.scalar(select(CustomEmoji).where(CustomEmoji.owner_id==settings.owner_id,CustomEmoji.key==key))
  if row:row.value=value
  else:s.add(CustomEmoji(owner_id=settings.owner_id,key=key,value=value))
  s.commit()
 await update.effective_message.reply_text(f'🎨 {key} = {value}')
async def role_create(update,context):
 if not is_owner(update.effective_user.id) or not context.args:return
 parts=' '.join(context.args).split('|')
 if len(parts)<6:return await update.effective_message.reply_text('Name|team|action|uses|target|win')
 with SessionLocal() as s:s.add(CustomRole(owner_id=settings.owner_id,name=parts[0],team=parts[1],night_action=parts[2],uses=int(parts[3]),target=parts[4],win_condition=parts[5]));s.commit()
 await update.effective_message.reply_text('✅ Custom role yaratildi.')
