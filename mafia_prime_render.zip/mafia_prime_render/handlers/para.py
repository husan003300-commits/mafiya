from telegram import Update
from telegram.ext import ContextTypes
from database.db import SessionLocal
from database.models import Para
async def para(update,context):
 with SessionLocal() as s:
  p=s.get(Para,update.effective_user.id)
 if p:return await update.effective_message.reply_text(f'💑 Para: {p.partner_id}')
 await update.effective_message.reply_text('💑 Para tizimi: /para ID — taklif yuborish (qabul qilish keyingi callback orqali).')
