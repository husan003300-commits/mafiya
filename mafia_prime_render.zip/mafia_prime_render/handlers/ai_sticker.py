import base64,io
from telegram import Update
from telegram.ext import ContextTypes
from config import settings
from handlers.admin import is_owner
async def generate_role_sticker(update,context):
 if not is_owner(update.effective_user.id):return
 if not settings.openai_api_key:return await update.effective_message.reply_text('❌ OPENAI_API_KEY sozlanmagan.')
 role=' '.join(context.args).strip() or 'Mafia'
 try:
  from openai import OpenAI
  client=OpenAI(api_key=settings.openai_api_key)
  r=client.images.generate(model=settings.openai_image_model,prompt=f'Game role sticker icon for {role}; clean, centered, transparent background, no gore')
  data=base64.b64decode(r.data[0].b64_json)
  await update.message.reply_document(io.BytesIO(data),filename=f'{role.replace(" ","_")}.png',caption=f'🎭 {role}')
 except Exception as e:await update.message.reply_text('❌ AI xatosi: '+str(e)[:250])
