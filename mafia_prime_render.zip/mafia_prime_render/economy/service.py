from database.db import SessionLocal
from database.models import User,Transaction
def transfer(sender,receiver,currency,amount):
 if amount<=0 or sender==receiver or currency not in ('money','diamonds'):return False,'Invalid transfer'
 with SessionLocal() as s:
  a=s.get(User,sender);b=s.get(User,receiver)
  if not a or not b:return False,'User not found'
  if getattr(a,currency)<amount:return False,'Insufficient balance'
  setattr(a,currency,getattr(a,currency)-amount);setattr(b,currency,getattr(b,currency)+amount);s.add(Transaction(from_user_id=sender,to_user_id=receiver,currency=currency,amount=amount,reason='user transfer'));s.commit()
 return True,'OK'
