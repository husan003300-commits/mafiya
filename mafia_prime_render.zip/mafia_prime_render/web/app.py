from datetime import datetime,timezone
from fastapi import FastAPI,HTTPException
from fastapi.responses import HTMLResponse
from sqlalchemy import select,func
from database.db import SessionLocal
from database.models import User,Game,Group
from config import settings
app=FastAPI(title='Mafia Prime Dashboard')
@app.get('/health')
async def health():return {'status':'ok','max_players':50}
@app.get('/',response_class=HTMLResponse)
async def home():
 return HTMLResponse('''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Mafia Prime</title><style>body{font-family:system-ui;background:#0b1020;color:#fff;padding:24px}.wrap{max-width:900px;margin:auto}.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px}.card{background:#151c32;padding:18px;border-radius:18px}button{padding:10px;border:0;border-radius:12px;margin:4px}</style></head><body><div class="wrap"><h1>🎭 MAFIA PRIME</h1><p>Telegram Mini App / dashboard backend</p><div class="grid"><div class="card">👤 PROFILE</div><div class="card">🎮 GAMES</div><div class="card">💰 WALLET</div><div class="card">💎 DIAMONDS</div><div class="card">💑 PARA</div><div class="card">🌟 PRO</div><div class="card">🦸 HERO</div><div class="card">🎁 BONUS</div><div class="card">🏆 TOP</div><div class="card">📊 STATISTICS</div><div class="card">🎒 INVENTORY</div><div class="card">⚙️ SETTINGS</div></div></div></body></html>''')
@app.get('/api/profile/{user_id}')
async def profile(user_id:int):
 with SessionLocal() as s:u=s.get(User,user_id)
 if not u:raise HTTPException(404,'User not found')
 return {'id':u.id,'username':u.username,'name':u.name,'money':u.money,'diamonds':u.diamonds,'xp':u.xp,'level':u.level,'games':u.games,'wins':u.wins,'losses':u.losses,'pro_until':u.pro_until,'hero_until':u.hero_until}
@app.get('/api/stats')
async def stats():
 with SessionLocal() as s:return {'users':s.scalar(select(func.count(User.id))),'groups':s.scalar(select(func.count(Group.id))),'games':s.scalar(select(func.count(Game.id))),'pro':s.scalar(select(func.count(User.id)).where(User.pro_until>datetime.now(timezone.utc)))}
