[29.09.2026 20:22] .: bot/
│
├── main.py
│
├── handlers/
│   ├── start.py
│   ├── mafia.py
│   ├── profile.py
│   ├── economy.py
│   ├── para.py
│   ├── admin.py
│   ├── bonus.py
│   └── web.py
│
├── game/
│   ├── engine.py
│   ├── roles.py
│   ├── night.py
│   ├── day.py
│   └── protection.py
│
├── economy/
│   ├── money.py
│   ├── diamonds.py
│   ├── transactions.py
│   └── rewards.py
│
├── database/
│   ├── db.py
│   ├── users.py
│   ├── games.py
│   └── groups.py
│
├── web/
│   ├── app.py
│   └── templates/
│
└── config.py                                                                                                                          Quyida katta Mafia botning **real ishlash ssenariysi**ni yozaman. Masalan, bir o‘yinda **4–50 ta o‘yinchi** qatnasha oladi. Tugmalar bosilganda bot callback orqali harakatni qabul qilishi mumkin; Telegram inline tugmalari xabar yubormasdan ham amal bajarishga imkon beradi.
🎭 1. BOTGA BIRINCHI KIRGANDA
Foydalanuvchi PM'da:


```
/start
```


bosadi.
Bot:


```
🎭 MAFIA PRIME

Assalomu alaykum, @User!

Bu bot orqali:
🎮 Mafia o'ynashingiz
💰 Money ishlashingiz
💎 Diamond yig'ishingiz
💑 Para bo'lishingiz
🌟 PRO/HERO imkoniyatlaridan foydalanishingiz
🏆 Reytinglarda qatnashishingiz mumkin.

👇 Menyudan tanlang:

[👤 Profil] [🎮 O'yin]
[💰 Iqtisodiyot] [💑 Para]
[🎁 Bonus] [🏆 Reyting]
[🌐 Web]
[📖 Yordam]
```


👤 2. PROFIL
`👤 Profil` bosiladi.
PM'da:


```
👤 SIZNING PROFILINGIZ

👤 Ism: Umid
🔗 Username: @user

💵 Money: 25,450
💎 Diamonds: 184

🎮 O'yinlar: 127
🏆 G'alabalar: 76
💀 Mag'lubiyatlar: 51

⭐️ Level: 18
✨ XP: 2,450 / 3,000

💑 Para: @Aziza

🌟 PRO: Faol
🦸 HERO: Faol

📅 PRO tugashi: 14 kun
```


Pastida:


```
[💰 Balans]
[📊 Statistikam]
[💑 Param]
[🌟 PRO]
[🦸 HERO]
```


🎮 3. GURUHDA MAFIA O'YINI
Bot guruhga qo‘shiladi.
Masalan guruhda 50 kishi bor.
Admin:


```
/game
```


yozadi.
Bot:


```
🎭 MAFIA O'YINI

O'yinga qo'shilish boshlandi!

👥 O'yinchilar: 0/50

Minimal: 4
Maksimal: 50

⏱️ Ro'yxatdan o'tish vaqti: 2 daqiqa

[🎮 O'yinga qo'shilish]
[❌ O'yindan chiqish]
[👥 O'yinchilar]
```


👥 4. O'YINGA QO'SHILISH
Ali:
**🎮 O'yinga qo'shilish** bosadi.
Guruhdagi xabar yangilanadi:


```
🎭 MAFIA O'YINI

👥 O'yinchilar: 1/50

1. 👤 Ali

[🎮 Qo'shilish]
[❌ Chiqish]
[👥 O'yinchilar]
```


Vali bosadi:


```
👥 O'yinchilar: 2/50

1. 👤 Ali
2. 👤 Vali
```


Shu tarzda **50 kishigacha**.
▶️ 5. O'YIN BOSHLANISHI
Masalan 12 kishi yig‘ildi.
Admin yoki avtomatik timer:


```
/startgame
```


Bot:


```
🎭 O'YIN BOSHLANDI!

👥 O'yinchilar: 12

🎲 Rollar taqsimlanmoqda...

⏳ Kuting...
```


Keyin har bir odamga **PM orqali alohida rol yuboriladi**.
Telegram bot foydalanuvchiga private chatda xabar yuborishi mumkin, o‘yin guruhidagi xabar esa umumiy holatni ko‘rsatadi.
📩 6. ROLE PM
Masalan Ali'ga Mafia tushdi.
Ali PM:


```
🎭 SIZNING ROLINGIZ

🔴 MAFIA

Siz — Mafia jamoasidasiz.

🎯 Maqsad:
Barcha raqib jamoalarni mag'lub qilish.

🌙 Tunda:
Siz nishon tanlaysiz.

👥 Mafia jamoadoshlari:
@Vali
@Hasan

⚠️ ROLINGIZNI GURUHGA AYTMANG.
```


Pastida:


```
[🌙 Tungi harakat]
[👥 Mafia]
[📖 Rol haqida]
```


📩 7. KOMISSAR PM
Komissarga:


```
🔎 SIZNING ROLINGIZ

🔵 KOMISSAR

🎯 Vazifangiz:
Mafia va boshqa rollarni aniqlash.

🌙 Har kecha:
1 ta o'yinchini tekshirishingiz mumkin.

[🔎 Tekshirish]
```


📩 8. DOKTOR PM


```
💉 SIZNING ROLINGIZ

🟢 DOKTOR

🎯 Vazifangiz:
O'yinchilarni tungi hujumdan himoya qilish.

🌙 Har kecha:
1 kishini davolashingiz mumkin.

[💉 Davolash]
```


🌙 9. TUN BOSHLANADI
Guruhda:


```
🌙 TUN 1

Shahar uxlamoqda...

🔴 Mafia harakat qilmoqda.
🔎 Komissar tekshiruv o'tkazmoqda.
💉 Doktor davolamoqda.

⏱️ Qolgan vaqt: 60 soniya
```


**Muhim:** harakatlarning o‘zi guruhga chiqmaydi. Ular PM'da amalga oshiriladi.
🔴 10. MAFIA PM'DA NIMA BO'LADI?
Ali:


```
[🌙 Tungi harakat]
```


bosadi.
Bot:


```
🌙 MAFIA HARAKATI

Kimni nishonga olasiz?

[👤 @User1]
[👤 @User2]
[👤 @User3]
[👤 @User4]
```


Ali `@User2`ni bosadi.
Bot:


```
🎯 Nishon qabul qilindi.

Siz @User2 ni tanladingiz.

[✅ Tasdiqlash]
[↩️ O'zgartirish]
```


Tasdiqlaydi:


```
✅ Tungi harakatingiz saqlandi.

🌙 Tun tugashini kuting.
```


🔎 11. KOMISSAR NIMA QILADI?
PM:


```
🔎 TEKSHIRUV

Kimni tekshirasiz?

[👤 User1]
[👤 User2]
[👤 User3]
```


User2 bosildi.
Bot:


```
🔎 TEKSHIRUV NATIJASI

👤 User2

Natija:
🔴 Mafia jamoasiga tegishli.

⚠️ Bu ma'lumot faqat sizga ko'rsatiladi.
```


Natija **guruhga chiqmaydi**.
💉 12. DOKTOR NIMA QILADI?


```
💉 DAVOLASH

Kimni himoya qilasiz?

[👤 User1]
[👤 User2]
[👤 User3]
```


User2:


```
✅ User2 himoya qilindi.

Agar unga tungi hujum bo'lsa,
himoya ishlashi mumkin.
```


☀️ 13. TONG
Guruhda:


```
☀️ TONG OTDI

🌙 1-tun yakunlandi.

Kecha:
🔴 Hujum amalga oshirildi.

💉 Himoya natijasi tekshirildi...

☀️ Kun boshlandi.
```


Agar hech kim o‘lmagan bo‘lsa:


```
🛡 Bugun hech kim o'lmadi.

Doktorning himoyasi ishladi.
```


Agar o‘yinchi chiqarilgan bo‘lsa:


```
💀 Bugun @User2 o'yindan chiqdi.

🎭 Uning roli:
🔵 Komissar
```


Bu qismni sozlamaga qarab **rolni ochish/yashirish** mumkin.
🗣 14. KUNDUZGI MUHOKAMA
Guruhda:


```
☀️ KUN 1

Tirik o'yinchilar:
1. Ali
2. Vali
3. Hasan
4. Umar
...

🗣 Muhokama boshlandi.

⏱️ 120 soniya
```


Odamlar guruhda oddiy yozishadi.
Timer tugaydi.


```
🗳 OVOZ BERISH BOSHLANDI

Kimni chiqaramiz?

[👤 Ali]
[👤 Vali]
[👤 Hasan]
[👤 Umar]
```


🗳 15. OVOZ BERISH
Ali `Vali`ni bosadi.
Bot unga PM yoki alert:


```
🗳 Siz @Vali ga ovoz berdingiz.
```


Guruhdagi umumiy xabar:


```
🗳 OVOZ BERISH

👤 Ali — ✅
👤 Vali — ❌
👤 Hasan — ❌
...

⏱️ 30 soniya qoldi.
```


Oxirida:


```
📊 OVOZ NATIJALARI

@Vali — 5 ovoz
@Ali — 3 ovoz
@Hasan — 2 ovoz

⚖️ Eng ko'p ovoz:
@Vali

💀 @Vali o'yindan chiqarildi.
```


⚖️ 16. TENG OVOZ
Masalan:


```
Ali — 4
Vali — 4
```


Bot:


```
⚖️ OVOZLAR TENG!

Qayta ovoz berish boshlanadi.

[👤 Ali]
[👤 Vali]
```


Yana teng bo‘lsa, oldindan belgilangan qoida ishlaydi:


```
⚖️ Yana teng natija.

Bugun hech kim chiqarilmadi.
```


🔄 17. KEYINGI TUN
Keyin:


```
🌙 TUN 2 BOSHLANDI
```


yana:
**Mafia → PM**
**Komissar → PM**
**Doktor → PM**
va boshqa maxsus rollar → PM.
Shu sikl:


```
🌙 Tun
 ↓
☀️ Tong
 ↓
🗣 Muhokama
 ↓
🗳 Ovoz
 ↓
💀 Chiqarish
 ↓
🌙 Keyingi tun
```


o‘yin tugaguncha davom etadi.
🛡 18. ROLLARNING BIR-BIRIGA QARSHI HIMOYASI
Bu yerda botning eng muhim qismi — **priority/interaction engine**.
Masalan:


```
Mafia → User
Doctor → User
```


Bot qaror qiladi:


```
Mafia hujumi
+
Doctor himoyasi
=
User tirik
```


Boshqa holatda:


```
Mafia → User
Shield → User
```


natija:


```
🛡 Himoya ishladi.
User tirik.
```


Yoki:


```
Mafia → User
Armor = 1
```


natija:


```
🛡 Armor ishladi.
Armor = 0
User tirik.
```


Shuning uchun har bir rolga:


```
attack_power
defense_power
priority
target_rules
cooldown
uses
```


kabi parametrlar beriladi.
💑 19. PARA TIZIMI
Endi sen aytgan **para**.
PM'da:


```
💑 PARA

[💌 Para taklif qilish]
[❤️ Mening param]
[💔 Paradan ajralish]
```


💌 Para taklif qilish
`Para taklif qilish` bosiladi.
Bot:


```
💑 PARA TAKLIFI

Username yoki foydalanuvchini tanlang:

Masalan:
@username
```


User:


```
@Aziza
```


Bot Aziza'ga PM:


```
💌 PARA TAKLIFI

👤 @Umid sizga para bo'lishni taklif qildi.

[❤️ Qabul qilish]
[❌ Rad etish]
```


❤️ 20. QABUL QILISH
Aziza:
**❤️ Qabul qilish**
bosadi.
Bot:


```
💑 PARA TASDIQLANDI!

👤 @Umid
❤️
👤 @Aziza

Endi sizlar para bo'ldingiz.
```


Umidga ham:


```
❤️ @Aziza para bo'lish taklifingizni qabul qildi.
```


💔 21. PARADAN AJRALISH
`💔 Paradan ajralish`
bosiladi.
Bot:


```
💔 PARADAN AJRALISH

Haqiqatan ham @Aziza bilan
para munosabatini tugatmoqchimisiz?

[❌ Ha, ajralamiz]
[↩️ Bekor qilish]
```


Tasdiqlasa:


```
💔 Para munosabati tugatildi.

Siz endi @Aziza bilan para emassiz.
```


💰 22. PUL O'TKAZISH
PM:


```
💰 BALANS

💵 Money: 25,450
💎 Diamond: 184

[💸 Pul yuborish]
[💎 Diamond yuborish]
```


`Pul yuborish`:


```
💸 KIMGA YUBORAMIZ?

Username kiriting:
```


Keyin:


```
💵 MIQDOR:

Masalan:
5000
```


Bot:


```
💸 TASDIQLASH

Kimga: @Aziza
Miqdor: 5,000 💵

Sizda qoladi:
20,450 💵

[✅ Yuborish]
[❌ Bekor qilish]
```


Yuborilganda:
**Umidga:**


```
✅ 5,000 💵 @Aziza ga yuborildi.
```


**Azizaga:**


```
💰 Siz @Umid dan 5,000 💵 oldingiz.
```


Va bazaga:


```
transactions_log
```


yoziladi.
💎 23. DIAMOND O'TKAZISH
Xuddi shu:


```
💎 DIAMOND YUBORISH

Kimga?
@Aziza

Miqdor?
10

[✅ Yuborish]
```


Natija:


```
💎 10 Diamond yuborildi.

Sizda:
174 💎
```


Qabul qiluvchiga:


```
💎 Siz @Umid dan 10 Diamond oldingiz.
```


🎁 24. BONUS
`🎁 Bonus`:


```
🎁 BONUS MARKAZI

[🎁 Kunlik bonus]
[🌐 Web bonus]
[⭐️ Level bonus]
[🎉 Event]
```


🌐 25. WEB APP
`🌐 Web` bosilganda Telegram ichida **Mini App/Web App** ochilishi mumkin. Telegram Bot API Web App tugmasini qo‘llab-quvvatlaydi va Web App URL HTTPS bo‘lishi kerak.
Masalan Web sahifa:
[29.09.2026 20:22] .: 

```
┌──────────────────────────┐
│ 🎭 MAFIA PRIME           │
│                          │
│ 👤 @Umid                 │
│                          │
│ 💵 25,450                │
│ 💎 184                   │
│                          │
│ ┌────────┐ ┌──────────┐ │
│ │ PROFIL │ │ INVENTAR │ │
│ └────────┘ └──────────┘ │
│                          │
│ ┌────────┐ ┌──────────┐ │
│ │ BONUS  │ │ PARA     │ │
│ └────────┘ └──────────┘ │
│                          │
│ ┌────────┐ ┌──────────┐ │
│ │ HERO   │ │ PRO      │ │
│ └────────┘ └──────────┘ │
│                          │
│ 🏆 TOP                     │
└──────────────────────────┘
```


🌐 26. WEB'DA PROFIL


```
👤 PROFILE

@Umid

💵 25,450
💎 184

⭐️ Level 18
🎮 Games 127
🏆 Wins 76

🌟 PRO ACTIVE
🦸 HERO ACTIVE
```


🎁 27. WEB DAILY BONUS
Masalan oddiy user:


```
🎁 DAILY WEB BONUS

Bugungi bonus:

💎 +1

[🎁 OLISH]
```


Bosadi:


```
✅ Bonus olindi!

+1 💎

Keyingi bonus:
24:00:00
```


HERO user:


```
🦸 HERO DAILY BONUS

Bugungi bonus:

💎 +2

[🦸 OLISH]
```


Ya'ni sen aytgan **oddiy = 1 diamond, HERO = 2 diamond** kabi qoida.
Bu bonus server tomonidan tekshirilishi kerak — faqat brauzerdagi JavaScriptga ishonib qolmaslik kerak.
🦸 28. HERO
Web:


```
🦸 HERO

Status: ACTIVE

Sizning bonuslaringiz:

💎 Daily: x2
💵 Reward: x2
🎁 Maxsus bonuslar: ON

[📖 Batafsil]
```


Masalan:


```
Oddiy:
Web bonus = 1 💎

HERO:
Web bonus = 2 💎
```


🌟 29. PRO
Web:


```
🌟 PRO

Status:
ACTIVE

Qolgan:
14 kun 7 soat

Imkoniyatlar:

✅ Maxsus profil
✅ PRO badge
✅ Qo'shimcha bonus
✅ Maxsus menyu
```


💳 30. PULLIK FUNKSIYALAR
Agar bot ichida raqamli mahsulot/obuna sotilsa, Telegram Stars orqali invoice/payment mexanizmidan foydalanish mumkin.
Masalan:


```
🌟 PRO

1 oy — XX Stars

[⭐️ PRO sotib olish]
```


Bosadi:


```
🧾 BUY PRO

Mahsulot:
PRO — 30 kun

Narx:
XX ⭐️ Stars

[💳 To'lash]
```


To‘lov tasdiqlangandan keyin:


```
✅ TO'LOV MUVAFFAQIYATLI

🌟 PRO 30 kunga faollashtirildi.
```


Bot payment holatini server tomonda tekshiradi. Telegram Bot API payment va invoice mexanizmlarini qo‘llab-quvvatlaydi.
🏆 31. TOP
Web yoki PM:


```
🏆 TOP O'YINCHILAR

🥇 @User1
🏆 1,250 XP

🥈 @User2
🏆 1,180 XP

🥉 @User3
🏆 1,050 XP
```


Filter:


```
[🏆 G'alabalar]
[💎 Diamonds]
[💵 Money]
[⭐️ XP]
```


🏢 32. GURUH SOZLAMALARI
Guruh admini:


```
/settings
```


Bot:


```
⚙️ GROUP SETTINGS

🎮 O'yin:
ON

💑 Para:
ON

💰 Economy:
ON

🎁 Bonus:
ON

🌟 PRO:
ON

🦸 HERO:
ON

👥 Max players:
50
```


Admin tugma bosib o‘zgartiradi:


```
👥 MAX PLAYERS

[20]
[30]
[40]
[50] ✅
```


👑 33. ADMIN PANEL
PM'da faqat ruxsatli admin:


```
👑 ADMIN PANEL

[👤 USERS]
[👥 GROUPS]
[🎮 GAMES]
[💰 ECONOMY]
[🌟 PRO]
[🦸 HERO]
[🎁 BONUSES]
[📢 BROADCAST]
[📊 STATISTICS]
[⚙️ SETTINGS]
```


Masalan **Users**:


```
👤 USER MANAGEMENT

[🔎 User qidirish]
[💰 Balans]
[💎 Diamonds]
[🌟 PRO]
[🦸 HERO]
[🚫 Block]
```


🛡 34. ENG MUHIMI — RUXSATLAR
Bot har bir tugma bosilganda:


```
Kim bosdi?
↓
Bu odam tirikmi?
↓
O'yinda bormi?
↓
Uning roli nima?
↓
Hozirgi faza nima?
↓
Bu harakatga haqqi bormi?
↓
Cooldown bormi?
↓
Natijani hisoblash
↓
Databasega yozish
↓
Userga natija
```


Masalan oddiy odam:


```
🔎 Tekshirish
```


tugmasini o‘zi yasab bosgan taqdirda ham server:


```
user.role != COMMISSAR
```


ekanini tekshiradi va:


```
❌ Siz bu harakatni bajara olmaysiz.
```


deydi.
Shuning uchun faqat tugmani yashirish **himoya emas** — serverning o‘zi ham har bir amalni tekshirishi kerak.
🧠 35. BUTUN MAFIA O'YINI BIR ZANJIRDA
Mana sen izlayotgan **“bosdim → nima bo‘ladi?”** ko‘rinishidagi to‘liq oqim:


```
/gamе
   ↓
🎮 Qo'shilish
   ↓
👥 4–50 player
   ↓
▶️ Start
   ↓
🎲 Rollar taqsimlanadi
   ↓
📩 Har kimga PM orqali roli
   ↓
🌙 TUN
   ↓
🔴 Mafia → PM → nishon
   ↓
🔎 Komissar → PM → tekshiruv
   ↓
💉 Doktor → PM → himoya
   ↓
🛡 Himoyalar hisoblanadi
   ↓
☀️ TONG
   ↓
💀 Natija
   ↓
🗣 MUHOKAMA
   ↓
🗳 OVOZ
   ↓
📊 Natijalar
   ↓
💀 Bir o'yinchi chiqariladi
   ↓
🏁 G'oliblik sharti tekshiriladi
   ↓
Agar tugamagan bo'lsa
   ↓
🌙 YANGI TUN
```


Parallel ravishda:


```
👤 PROFIL
├── 💵 Money
├── 💎 Diamonds
├── ⭐️ XP
├── 🏆 Stats
├── 💑 Para
├── 🌟 PRO
└── 🦸 HERO
```


va:


```
🌐 WEB
├── Profil
├── Balance
├── Bonus
├── Para
├── HERO
├── PRO
├── TOP
└── Statistics
```


**Shu darajada yozilsa, dasturchiga “Mafia bot yasab ber” deyishning o‘zi yetarli bo‘lmaydi — u aynan qaysi tugma nima qilishi, PMda nima chiqishi, guruhda nima chiqishi va databasega nima yozilishini tushunadi.**
Yana bir muhim texnik nuqta: **Web, bot va database bitta markaziy backend bilan ishlashi kerak**. Masalan Web'da `+1 💎` berilganda faqat sahifadagi raqamni o‘zgartirish emas, server database'dagi balansni ham atomik tarzda yangilashi kerak. Aks holda foydalanuvchi bonusni takroran olishga olib keladigan xatolar paydo bo‘lishi mumkin.
xop yana qande funksiyala botning owner va botninng admin paneli keyin pro belgsi botdan berish costume emoji qoshish va style success 3 xili va yana qande mukamal funksiyalar davom etaver
Ha. Endi **owner + admin panel + PRO/HERO + custom emoji + button style + mukammal boshqaruv** qismini ham qo‘shamiz.
Telegram Bot API hozir tugmalarda **custom emoji** va `primary / success / danger` kabi button style'larini qo‘llab-quvvatlaydi. Custom emoji ishlatish uchun bot/owner hisobiga tegishli Telegram shartlari ham bor.
👑 1. OWNER TIZIMI
**Owner** — botning eng yuqori darajadagi egasi.
Masalan:


```
👑 OWNER PANEL

Bot: @MafiaPrimeBot

👥 Users: 18,492
👥 Groups: 1,284
🎮 Games today: 347

💰 Economy
💎 Diamonds
🌟 PRO
🦸 HERO

⚙️ Bot settings
🛡 Security
📢 Broadcast
📊 Statistics
🌐 Web
🗄 Database
```


Owner uchun alohida huquqlar:
admin qo‘shish
adminni olib tashlash
admin darajasini o‘zgartirish
userga PRO berish
userdan PRO olish
userga HERO berish
userdan HERO olish
Money berish
Diamond berish
userni block/unblock
guruhni block/unblock
guruhga premium status berish
bot maintenance rejimi
broadcast
barcha statistikani ko‘rish
loglarni ko‘rish
iqtisodiyotni sozlash
bonus miqdorini o‘zgartirish
🛡 2. ADMIN DARAJALARI
Hamma admin bir xil huquqqa ega bo‘lmasin.
Owner


```
👑 OWNER
```


Hammasini boshqaradi.
Super Admin


```
🔴 SUPER ADMIN
```


user
group
broadcast
moderation
game
Admin


```
🟠 ADMIN
```


user moderation
group moderation
o‘yin nazorati
Moderator


```
🟢 MODERATOR
```


Faqat:
mute
ban
game moderation
Masalan:


```
👤 ADMIN

@admin1
Role: Moderator

Permissions:
✅ Ban
✅ Mute
❌ Economy
❌ PRO
❌ HERO
❌ Owner settings
```


Shunda adminning qo‘lida keragidan ortiq vakolat bo‘lmaydi.
⚙️ 3. PERMISSION BUILDER
Owner xohlasa har bir admin uchun huquqni alohida yoqadi/o‘chiradi.


```
🛡 PERMISSIONS

👤 @admin

[✅] Users
[✅] Groups
[❌] Economy
[❌] PRO
[❌] HERO
[✅] Games
[❌] Broadcast
[❌] Settings
```


Bu juda foydali.
🌟 4. BOTDAN PRO BERISH
Owner/Admin panel:


```
🌟 PRO MANAGEMENT

[➕ PRO berish]
[➖ PRO olish]
[🔎 PRO qidirish]
[📋 PRO users]
```


`➕ PRO berish`:


```
👤 Username:

@user
```


Keyin:


```
🌟 PRO MUDDATI

[1 kun]
[7 kun]
[30 kun]
[90 kun]
[365 kun]
[♾️ Custom]
```


Masalan `30 kun`:


```
✅ PRO berildi

👤 @user
🌟 PRO: ACTIVE
⏳ Muddat: 30 kun
```


Userga PM:


```
🌟 TABRIKLAYMIZ!

Sizga administrator tomonidan
PRO status berildi.

⏳ Muddat: 30 kun
```


🦸 5. HERO BERISH
Xuddi shunday:


```
🦸 HERO MANAGEMENT

[➕ HERO berish]
[➖ HERO olish]
[🔎 HERO users]
```


Muddat:


```
[1 kun]
[7 kun]
[30 kun]
[∞]
```


Userga:


```
🦸 HERO STATUS AKTIV!

Siz Hero imkoniyatlariga ega bo'ldingiz.

💎 Bonus multiplier: x2
💰 Reward multiplier: x2
🎁 Maxsus bonuslar: ON
```


✨ 6. PRO + HERO BIRGA
Masalan user:


```
🌟 PRO: ACTIVE
🦸 HERO: ACTIVE
```


Bot barcha imkoniyatlarni birlashtiradi.
Lekin kodda:


```
has_pro(user)
has_hero(user)
```


alohida tekshiriladi.
Shuning uchun:
**PRO borligi HERO bor degani emas.**
🎨 7. CUSTOM EMOJI
Masalan menyuda oddiy:


```
💰 Balans
💎 Diamonds
```


o‘rniga maxsus Telegram emoji ishlatilishi mumkin:


```
[💎 Balans]
[🦸 HERO]
[🌟 PRO]
```


Bot API custom emoji ID bilan ishlashni qo‘llab-quvvatlaydi. Tugmalarda ham custom emoji icon ishlatish mumkin.
Masalan menyu:


```
[💎  BALANS]
[🦸  HERO]
[🌟  PRO]
[💑  PARA]
```


Owner panelda:


```
🎨 CUSTOM EMOJI

Profile icon: [tanlash]
Money icon: [tanlash]
Diamond icon: [tanlash]
Hero icon: [tanlash]
Pro icon: [tanlash]
Game icon: [tanlash]
```


🔵 8. BUTTON STYLE — 3 XIL
Telegram hozir tugmalar uchun:


```
primary
success
danger
```


style'larini beradi.
Masalan:
🔵 Primary


```
[🎮 O'YIN]
```


🟢 Success


```
[✅ TASDIQLASH]
```


🔴 Danger


```
[❌ O'CHIRISH]
```


Shuning uchun admin panelda:


```
🎨 BUTTON STYLE

🎮 Game → Primary
✅ Confirm → Success
❌ Delete → Danger
```


🎨 9. BOTNING UMUMIY STYLE TIZIMI
Owner:


```
🎨 BOT DESIGN

[Default]
[Dark]
[Premium]
```


Masalan **Premium style**:


```
━━━━━━━━━━━━━━
      🎭 MAFIA
━━━━━━━━━━━━━━

👤 PROFILE
💎 BALANCE
🌟 PRO
🦸 HERO

━━━━━━━━━━━━━━
```


[29.09.2026 20:22] .: Barcha xabarlar bir xil dizaynda chiqadi.
📝 10. MESSAGE TEMPLATE SYSTEM
Eng kuchli funksiyalardan biri.
Owner:


```
📝 MESSAGE TEMPLATES

[start]
[profile]
[game_start]
[game_night]
[game_day]
[vote]
[death]
[win]
[lose]
[para]
[transfer]
[bonus]
[pro]
[hero]
```


Masalan Owner `game_start`ni o‘zgartiradi:


```
🎭 {game_name}

👥 O'yinchilar: {players}/{max_players}

🌙 Birinchi tun boshlanmoqda...
```


Bot avtomatik o‘zgaruvchilarni almashtiradi:


```
{username}
{user_id}
{money}
{diamonds}
{level}
{players}
{max_players}
{game_id}
{role}
```


Bu botni juda oson sozlanadigan qiladi.
🌍 11. 3 TIL
Masalan:


```
🇺🇿 O'zbekcha
🇷🇺 Русский
🇬🇧 English
```


User:


```
🌍 LANGUAGE

[🇺🇿 Uzbek]
[🇷🇺 Русский]
[🇬🇧 English]
```


Tanlagandan keyin butun menyu o‘zgaradi.
Telegram botlar turli tillarda foydalanuvchi tiliga mos ishlashi mumkin.
📢 12. BROADCAST
Owner:


```
📢 BROADCAST

[👥 All users]
[👥 Active users]
[👥 PRO users]
[🦸 HERO users]
[👥 Groups]
```


Masalan:


```
📢 Yangi event boshlandi!

🎁 1000 Diamond prize.
```


Keyin:


```
[✅ SEND]
[❌ CANCEL]
```


Bot yuboradi.
📊 13. OWNER STATISTIKA


```
📊 BOT STATISTICS

👤 Users:
18,492

🟢 Active today:
4,287

👥 Groups:
1,284

🎮 Games today:
347

💎 Diamonds in circulation:
2,845,192

💵 Money in circulation:
184,921,000

🌟 PRO:
842

🦸 HERO:
317
```


💰 14. ECONOMY CONTROL
Owner:


```
💰 ECONOMY SETTINGS

Daily bonus:
💵 1000
💎 2

Web bonus:
💎 1

Hero web bonus:
💎 2

Win reward:
💵 500

Hero win reward:
💵 1000
```


Masalan Owner:


```
Web bonus = 1
```


ni


```
Web bonus = 2
```


qilsa, hamma userda yangi qiymat ishlaydi.
🧮 15. TRANSACTION HISTORY
Har bir pul harakati yoziladi:


```
💸 TRANSACTION

From: @Ali
To: @Vali

Amount:
💵 5,000

Time:
29.09.2026 19:30

Reason:
User transfer

Transaction ID:
#TX92831
```


Shuning uchun keyinchalik:
**“Mening 5000 pulim qayerga ketdi?”**
degan savolga tarixdan ko‘rish mumkin.
🔎 16. USER SEARCH
Admin:


```
🔎 USER SEARCH
```


Username:


```
@user
```


Natija:


```
👤 USER

ID: 123456789
Username: @user

💵 25,400
💎 184

🌟 PRO: YES
🦸 HERO: NO

🎮 Games: 127
🏆 Wins: 76

🚫 Block: NO
```


🚫 17. BLOCK SYSTEM
Admin:


```
🚫 BLOCK USER

Reason:
Spam
```


User botga kirsa:


```
🚫 Siz botdan foydalanishingiz bloklangan.

Sabab:
Spam

Muddat:
7 kun
```


Owner:


```
[🔓 Unblock]
```


qilib ochishi mumkin.
👥 18. GROUP MANAGEMENT
Owner:


```
👥 GROUPS

🔎 Search
📊 Statistics
🚫 Blocked groups
🌟 Premium groups
```


Guruh:


```
🎭 Mafia Prime

👥 Members: 8,420
🎮 Games: 3,821

🌟 Premium: YES

Owner:
@admin
```


🏆 19. GROUP LEVEL
Guruh ham level olishi mumkin.
Masalan:


```
🏢 GROUP LEVEL

Level: 12
XP: 8,450/10,000

🎮 Games: 421
🏆 Wins: 218
```


Level oshgani sari:
yangi rollar
max player
bonus
maxsus badge
statistika
ochiladi.
🌐 20. WEB — FAQAT BALANS EMAS
Web Mini Appni to‘liq **Mafia dashboard** qilish mumkin. Telegram Mini Apps JavaScript asosida to‘liq interaktiv web interfeys sifatida ishlashi mumkin.
Masalan:


```
🌐 MAFIA PRIME WEB

🏠 HOME
👤 PROFILE
🎮 GAMES
💰 WALLET
💎 DIAMONDS
💑 PARA
🌟 PRO
🦸 HERO
🎁 BONUS
🏆 TOP
📊 STATISTICS
🎨 INVENTORY
⚙️ SETTINGS
```


🛍 21. INVENTORY
User yig‘gan narsalar:


```
🎒 INVENTORY

🦸 Hero Badge
🌟 PRO Badge
💎 Diamond Pack
🎨 Profile Frame
🏆 Champion Badge
```


Keyin profil:


```
👤 @User

🦸 HERO
🏆 CHAMPION
🌟 PRO
```


ko‘rinishida chiqishi mumkin.
🖼 22. PROFILE CUSTOMIZATION
User:


```
🎨 PROFILE DESIGN
```


bosadi:


```
[🎨 Avatar]
[🖼 Frame]
[🏷 Badge]
[✨ Style]
```


Masalan:


```
👤 @Umid

🏆 Champion
🦸 Hero
🌟 PRO
```


🔔 23. NOTIFICATION CENTER
Web'da:


```
🔔 NOTIFICATIONS

💎 Sizga 10 Diamond yuborildi.
💑 @User para taklif qildi.
🌟 PRO 3 kundan keyin tugaydi.
🎁 Daily bonus tayyor.
🏆 Siz TOP 10 ga kirdingiz.
```


🔗 24. REFERRAL
User:


```
👥 INVITE FRIENDS
```


Bot:


```
🔗 Sizning linkingiz:

t.me/MafiaPrimeBot?start=ref_123456
```


Telegram deep linking orqali botga parametr yuborish mumkin.
Masalan:


```
1 ta do'st → 💎 2
5 ta → 💎 15
10 ta → 🌟 PRO 1 kun
```


Lekin rewardlar server tomonidan tekshiriladi, takroriy/soxta referral hisoblanmaydi.
🏅 25. ACHIEVEMENTS
Masalan:


```
🏅 ACHIEVEMENTS

🔒 First Blood
🔒 10 Wins
🔓 50 Games
🔒 Mafia Master
🔒 Survivor
🔒 Doctor
🔒 Commissioner
```


Ochilganda:


```
🏆 ACHIEVEMENT UNLOCKED!

🎖 Mafia Master

50 ta Mafia o'yinida qatnashdingiz.

Reward:
💎 +10
```


🧠 26. ENG KUCHLI QISM — EVENT SYSTEM
Owner yangi event yaratadi:


```
🎉 EVENT

Nomi:
Mafia Weekend

Boshlanish:
01.10.2026

Tugash:
05.10.2026

Bonus:
2x XP

Hero:
4x XP
```


O'yinlar avtomatik:


```
🎉 EVENT ACTIVE

XP ×2
```


🔐 27. SECURITY
Har bir muhim action:


```
user_id
action
target
timestamp
ip/session (web uchun zarur bo‘lsa)
result
```


bo‘yicha audit qilinishi mumkin.
Va eng muhimi, **admin tugmasini ko‘rsatishning o‘zi permission emas**. Backend har safar:


```
Is owner?
Is admin?
Which permission?
Is this action allowed?
```


deb tekshiradi. Telegramning o‘zi ham command scope faqat ko‘rinishni boshqarishini, backend esa kelgan komandani qaytadan authorization qilishi kerakligini aytadi.
🚀 28. MEN SENGA TAVSIYA QILADIGAN YAKUNIY TIZIM
Botni shunday 8 qavatli qilish mumkin:


```
                    🎭 MAFIA PRIME
                          │
        ┌─────────────────┼─────────────────┐
        │                 │                 │
      👤 USER            🎮 GAME           👑 OWNER
        │                 │                 │
   💰 Economy          🎭 Roles          🛡 Admin
   💑 Para             🌙 Night          ⚙️ Settings
   🌟 PRO              ☀️ Day            📢 Broadcast
   🦸 HERO             🗳 Vote           📊 Statistics
   🎁 Bonus            🏆 Winner         💎 Economy
        │                 │                 │
        └─────────────────┼─────────────────┘
                          │
                     🌐 MINI APP
                          │
          ┌───────────────┼───────────────┐
          │               │               │
       Profile         Wallet           Bonus
       Para            Diamond          HERO
       PRO             Statistics        TOP
```


Shunda bu **oddiy Mafia bot emas**, balki **Mafia + Economy + Social + PRO/HERO + Web Mini App + Owner/Admin platforma** bo‘ladi. Telegram Mini Apps buning web-dashboard qismini Telegram ichida ochishga mos keladi