[29.09.2026 20:41] .: Barcha xabarlar bir xil dizaynda chiqadi.
📝 10. MESSAGE TEMPLATE SYSTEM
Eng kuchli funksiyalardan biri.
Owner:


```
📝 MESSAGE TEMPLATES

[start]
[profile]
[game_start]
[game_night]
[game_day]
[vote]
[death]
[win]
[lose]
[para]
[transfer]
[bonus]
[pro]
[hero]
```


Masalan Owner `game_start`ni o‘zgartiradi:


```
🎭 {game_name}

👥 O'yinchilar: {players}/{max_players}

🌙 Birinchi tun boshlanmoqda...
```


Bot avtomatik o‘zgaruvchilarni almashtiradi:


```
{username}
{user_id}
{money}
{diamonds}
{level}
{players}
{max_players}
{game_id}
{role}
```


Bu botni juda oson sozlanadigan qiladi.
🌍 11. 3 TIL
Masalan:


```
🇺🇿 O'zbekcha
🇷🇺 Русский
🇬🇧 English
```


User:


```
🌍 LANGUAGE

[🇺🇿 Uzbek]
[🇷🇺 Русский]
[🇬🇧 English]
```


Tanlagandan keyin butun menyu o‘zgaradi.
Telegram botlar turli tillarda foydalanuvchi tiliga mos ishlashi mumkin.
📢 12. BROADCAST
Owner:


```
📢 BROADCAST

[👥 All users]
[👥 Active users]
[👥 PRO users]
[🦸 HERO users]
[👥 Groups]
```


Masalan:


```
📢 Yangi event boshlandi!

🎁 1000 Diamond prize.
```


Keyin:


```
[✅ SEND]
[❌ CANCEL]
```


Bot yuboradi.
📊 13. OWNER STATISTIKA


```
📊 BOT STATISTICS

👤 Users:
18,492

🟢 Active today:
4,287

👥 Groups:
1,284

🎮 Games today:
347

💎 Diamonds in circulation:
2,845,192

💵 Money in circulation:
184,921,000

🌟 PRO:
842

🦸 HERO:
317
```


💰 14. ECONOMY CONTROL
Owner:


```
💰 ECONOMY SETTINGS

Daily bonus:
💵 1000
💎 2

Web bonus:
💎 1

Hero web bonus:
💎 2

Win reward:
💵 500

Hero win reward:
💵 1000
```


Masalan Owner:


```
Web bonus = 1
```


ni


```
Web bonus = 2
```


qilsa, hamma userda yangi qiymat ishlaydi.
🧮 15. TRANSACTION HISTORY
Har bir pul harakati yoziladi:


```
💸 TRANSACTION

From: @Ali
To: @Vali

Amount:
💵 5,000

Time:
29.09.2026 19:30

Reason:
User transfer

Transaction ID:
#TX92831
```


Shuning uchun keyinchalik:
**“Mening 5000 pulim qayerga ketdi?”**
degan savolga tarixdan ko‘rish mumkin.
🔎 16. USER SEARCH
Admin:


```
🔎 USER SEARCH
```


Username:


```
@user
```


Natija:


```
👤 USER

ID: 123456789
Username: @user

💵 25,400
💎 184

🌟 PRO: YES
🦸 HERO: NO

🎮 Games: 127
🏆 Wins: 76

🚫 Block: NO
```


🚫 17. BLOCK SYSTEM
Admin:


```
🚫 BLOCK USER

Reason:
Spam
```


User botga kirsa:


```
🚫 Siz botdan foydalanishingiz bloklangan.

Sabab:
Spam

Muddat:
7 kun
```


Owner:


```
[🔓 Unblock]
```


qilib ochishi mumkin.
👥 18. GROUP MANAGEMENT
Owner:


```
👥 GROUPS

🔎 Search
📊 Statistics
🚫 Blocked groups
🌟 Premium groups
```


Guruh:


```
🎭 Mafia Prime

👥 Members: 8,420
🎮 Games: 3,821

🌟 Premium: YES

Owner:
@admin
```


🏆 19. GROUP LEVEL
Guruh ham level olishi mumkin.
Masalan:


```
🏢 GROUP LEVEL

Level: 12
XP: 8,450/10,000

🎮 Games: 421
🏆 Wins: 218
```


Level oshgani sari:
yangi rollar
max player
bonus
maxsus badge
statistika
ochiladi.
🌐 20. WEB — FAQAT BALANS EMAS
Web Mini Appni to‘liq **Mafia dashboard** qilish mumkin. Telegram Mini Apps JavaScript asosida to‘liq interaktiv web interfeys sifatida ishlashi mumkin.
Masalan:


```
🌐 MAFIA PRIME WEB

🏠 HOME
👤 PROFILE
🎮 GAMES
💰 WALLET
💎 DIAMONDS
💑 PARA
🌟 PRO
🦸 HERO
🎁 BONUS
🏆 TOP
📊 STATISTICS
🎨 INVENTORY
⚙️ SETTINGS
```


🛍 21. INVENTORY
User yig‘gan narsalar:


```
🎒 INVENTORY

🦸 Hero Badge
🌟 PRO Badge
💎 Diamond Pack
🎨 Profile Frame
🏆 Champion Badge
```


Keyin profil:


```
👤 @User

🦸 HERO
🏆 CHAMPION
🌟 PRO
```


ko‘rinishida chiqishi mumkin.
🖼 22. PROFILE CUSTOMIZATION
User:


```
🎨 PROFILE DESIGN
```


bosadi:


```
[🎨 Avatar]
[🖼 Frame]
[🏷 Badge]
[✨ Style]
```


Masalan:


```
👤 @Umid

🏆 Champion
🦸 Hero
🌟 PRO
```


🔔 23. NOTIFICATION CENTER
Web'da:


```
🔔 NOTIFICATIONS

💎 Sizga 10 Diamond yuborildi.
💑 @User para taklif qildi.
🌟 PRO 3 kundan keyin tugaydi.
🎁 Daily bonus tayyor.
🏆 Siz TOP 10 ga kirdingiz.
```


🔗 24. REFERRAL
User:


```
👥 INVITE FRIENDS
```


Bot:


```
🔗 Sizning linkingiz:

t.me/MafiaPrimeBot?start=ref_123456
```


Telegram deep linking orqali botga parametr yuborish mumkin.
Masalan:


```
1 ta do'st → 💎 2
5 ta → 💎 15
10 ta → 🌟 PRO 1 kun
```


Lekin rewardlar server tomonidan tekshiriladi, takroriy/soxta referral hisoblanmaydi.
🏅 25. ACHIEVEMENTS
Masalan:


```
🏅 ACHIEVEMENTS

🔒 First Blood
🔒 10 Wins
🔓 50 Games
🔒 Mafia Master
🔒 Survivor
🔒 Doctor
🔒 Commissioner
```


Ochilganda:


```
🏆 ACHIEVEMENT UNLOCKED!

🎖 Mafia Master

50 ta Mafia o'yinida qatnashdingiz.

Reward:
💎 +10
```


🧠 26. ENG KUCHLI QISM — EVENT SYSTEM
Owner yangi event yaratadi:


```
🎉 EVENT

Nomi:
Mafia Weekend

Boshlanish:
01.10.2026

Tugash:
05.10.2026

Bonus:
2x XP

Hero:
4x XP
```


O'yinlar avtomatik:


```
🎉 EVENT ACTIVE

XP ×2
```


🔐 27. SECURITY
Har bir muhim action:


```
user_id
action
target
timestamp
ip/session (web uchun zarur bo‘lsa)
result
```


bo‘yicha audit qilinishi mumkin.
Va eng muhimi, **admin tugmasini ko‘rsatishning o‘zi permission emas**. Backend har safar:


```
Is owner?
Is admin?
Which permission?
Is this action allowed?
```


deb tekshiradi. Telegramning o‘zi ham command scope faqat ko‘rinishni boshqarishini, backend esa kelgan komandani qaytadan authorization qilishi kerakligini aytadi.
🚀 28. MEN SENGA TAVSIYA QILADIGAN YAKUNIY TIZIM
Botni shunday 8 qavatli qilish mumkin:


```
                    🎭 MAFIA PRIME
                          │
        ┌─────────────────┼─────────────────┐
        │                 │                 │
      👤 USER            🎮 GAME           👑 OWNER
        │                 │                 │
   💰 Economy          🎭 Roles          🛡 Admin
   💑 Para             🌙 Night          ⚙️ Settings
   🌟 PRO              ☀️ Day            📢 Broadcast
   🦸 HERO             🗳 Vote           📊 Statistics
   🎁 Bonus            🏆 Winner         💎 Economy
        │                 │                 │
        └─────────────────┼─────────────────┘
                          │
                     🌐 MINI APP
                          │
          ┌───────────────┼───────────────┐
          │               │               │
       Profile         Wallet           Bonus
       Para            Diamond          HERO
       PRO             Statistics        TOP
```


Shunda bu **oddiy Mafia bot emas**, balki **Mafia + Economy + Social + PRO/HERO + Web Mini App + Owner/Admin platforma** bo‘ladi. Telegram Mini Apps buning web-dashboard qismini Telegram ichida ochishga mos keladi
[30.09.2026 18:20] .: 👥 Minimum 4, maksimum 40 o‘yinchi
/start bilan o‘yinni boshlash
🎭 Random rollar
🌙 Tun
☀️ Kunduz
🗳 Ovoz berish
🔫 O‘yin ichidagi harakatlar
🏁 G‘olibni aniqlash
📊 O‘yin yakuniy statistikasi
🔄 Keyingi o‘yinga qayta qo‘shilish
🎭 2. Rollar
4 kishi:
👑 Don
🔪 Mafia
🕵️ Komissar
💉 Doktor
5–40 kishi:
yuqoridagi rollar + maxsus rollar random qo‘shiladi.
Maxsus rollar:
🧙 Afsungar
⚖️ Sudya
👑 Rais
🥷 Niqobchi
🕵️ Detektiv
🏃 Oddiy fuqaro
va keyinchalik boshqa maxsus rollar.
🌙 3. Tun tizimi
🔪 Mafia harakati
👑 Don harakati
💉 Doktor davolashi
🕵️ Komissar tekshiruvi
🎭 Maxsus rollarning qobiliyatlari
⏱ Harakatlar uchun vaqt
🔔 Shaxsiy bildirishnomalar
☀️ 4. Kunduz tizimi
📢 Tirik o‘yinchilar
💬 Muhokama
🗳 Ovoz berish
⚖️ Sudya/Rais kabi rollarning maxsus imkoniyatlari
💀 O‘lgan o‘yinchilar alohida ko‘rsatiladi
🕵️ 5. Maxfiy tizimlar
🕶 Yashirin ittifoqlar
📞 Maxfiy aloqa
💰 Pora
📂 Dalillar
🎭 Soxta identitet
🔎 Shubha darajasi
🕵️ Maxfiy topshiriqlar
💰 6. Iqtisodiyot
💵 Dollar
💎 Olmos
⭐ XP
📈 Level
🏆 Reyting
🔥 Streak
🎁 Kunlik bonus
📊 Statistikalar
🏅 Achievement
🛒 7. Do‘kon
🛡 Himoya
📄 Hujjat
🔫 Miltiq
💊 Dori
🎭 Maska
🛡 Qotildan himoya
🪄 Maxsus buyumlar
🃏 Kartalar
🎟 Maxsus event buyumlari
💎 Noyob kolleksion buyumlar
👑 8. VIP
👑 VIP status
🎁 VIP bonuslar
🛒 VIP do‘kon
🃏 VIP kartalar
🎖 VIP unvonlar
🏆 VIP statistikalar
📈 9. Level va Skill
🔰 Level 1 → yuqori level
🎯 XP yig‘ish
🎭 Har bir rol bo‘yicha tajriba
🧬 Skill tizimi
🎖 Levelga qarab unvonlar
🔓 Progress orqali yangi imkoniyatlar
🏆 10. Reyting
🌍 Global reyting
📅 Kunlik reyting
📆 Haftalik reyting
🗓 Oylik reyting
👥 Oila reytingi
🏙 Shahar reytingi
🥇🥈🥉 Top o‘yinchilar
🏛 Hall of Fame
🔥 11. Season
🏆 Season tizimi
🎟 Season Pass
🎁 Season mukofotlari
📊 Season reytingi
🔄 Har yangi Season yangi maqsadlar
🎯 12. Achievement
Masalan:
🩸 Birinchi g‘alaba
👑 Don sifatida g‘alaba
🔪 Mafia sifatida g‘alaba
🕵️ 10 ta to‘g‘ri tekshiruv
🛡 Ko‘p marta omon qolish
🔥 Ketma-ket g‘alabalar
🏆 Turnir yutish
🎁 13. Sandiq va mukofotlar
🎁 Sirli sandiq
💵 Pul
💎 Olmos
🃏 Karta
🎟 Event chip
🏅 Noyob buyumlar
🎲 14. Random Eventlar
⚡ Elektr o‘chishi
🚨 Politsiya reydi
💰 Bank voqeasi
🎁 Sirli sovg‘a
🕵️ Maxfiy ma’lumot
🌃 Maxsus Carleone eventlari
🏙 15. Carleone City
🏦 Bank
🏥 Kasalxona
👮 Politsiya
🍸 Club
🏠 Uy
🏢 Biznes
🚗 Garaj
🛒 Market
👑 VIP Club
🏠 16. Uy tizimi
🏠 Oddiy uy
🏡 Yaxshiroq uy
🏢 Villa
🏰 Mansion
🎨 Uy bezaklari
📈 Uy leveli
🚗 17. Mashina tizimi
🚗 Mashina kolleksiyasi
🔧 Mashina upgrade
🎨 Kosmetik bezaklar
🏆 Noyob mashinalar
🚘 Garaj
💼 18. Biznes
🏪 Biznes sotib olish
💰 Passiv daromad
📈 Biznes upgrade
🏢 Turli bizneslar
🏆 Biznes reytingi
👥 19. Mafia Family / Clan
👑 Boss
🕴 A'zolar
🏆 Oila reytingi
💰 Oila kassasi
🎁 Oila bonuslari
⚔️ Oilalar o‘rtasidagi turnirlar
⚔️ 20. Turnirlar
🏟 Carleone Cup
🏆 Maxsus turnirlar
📊 Turnir jadvali
🎁 Mukofotlar
🥇🥈🥉 G‘oliblar
🤝 21. Para tizimi
/mypara
💍 Para taklifi
✅ Qabul qilish
❌ Rad etish
👥 Para profilda ko‘rinadi
🎁 Para uchun maxsus bonuslar
🃏 22. Karta tizimi
🛡 Himoya kartasi
🎭 Maska kartasi
🩹 Qutqaruv kartasi
🕵️ Tekshiruv kartasi
🃏 Maxsus noyob kartalar
📚 Karta kolleksiyasi
🎰 23. Mini-o‘yinlar
🎲 Dice
🃏 Cards
🎯 Target
🪙 Coin
Bular alohida o‘yin ichidagi virtual valyuta bilan ishlaydi.
📰 24. Carleone News
📰 @Mafia_Carleonenews
🏆 Yangi rekordlar
🎉 Eventlar
🥇 Reyting yangiliklari
👑 Maxsus o‘yinchilar haqidagi yangiliklar
👤 25. Profil
👤 Ism
💵 Dollar
💎 Olmos
⭐ XP
📈 Level
🏆 G‘alabalar
🎮 O‘yinlar
🎭 Rollar statistikasi
🔥 Streak
🏅 Achievementlar
👑 VIP
💍 Para
🎖 Unvon
🖼 Profil kartasi
🎖 26. Unvonlar
Masalan:
🔰 Boshlovchi
🔫 Qotil
🕵️ Tergovchi
👑 Don
💀 Carleone Afsonasi
📜 27. O‘yin tarixi
Oxirgi o‘yinlar
O‘ynagan roli
G‘alaba/mag‘lubiyat
O‘yin davomiyligi
O‘yindagi statistikalar
Match History
🏛 28. Mafia Museum
🏆 Noyob achievementlar
🃏 Kolleksion kartalar
🎁 Noyob buyumlar
🏆 Tarixiy turnirlar
👑 Maxsus rekordlar
⭐ 29. Reputation
⭐ Carleone Reputation
G‘alabalar
Turnirlar
Achievementlar
Eventlardagi natijalar asosida rivojlanadi.
📅 30. Vazifalar
🎯 Kunlik vazifalar
📆 Haftalik vazifalar
🏆 Season vazifalari
🎁 Mukofotlar
🎉 31. Eventlar
🎃 Maxsus mavsumiy eventlar
🎄 Bayram eventlari
🔥 Carleone maxsus eventlari
🎁 Event mukofotlari
🔐 32. Promo-kodlar
🎟 Promo-kod
💵 Pul mukofoti
💎 Olmos
🎁 Buyum
👑 Maxsus bonus
🖼 33. Profil dizayni
🖼 Profil kartasi
🎨 Ramkalar
🎖 Badge
👑 Maxsus unvonlar
🎭 Profil bezaklari
🌐 34. Tillar
🇺🇿 O‘zbekcha
🇷🇺 Ruscha
🇬🇧 Inglizcha
📊 35. Live statistika
O‘yin paytida:
👥 Tirik: 7
💀 O‘lgan: 3
🌙 Tun: 3
🔪 Mafia: ?
🤖 36. Aqlli bot tizimlari
⏱ Avtomatik timer
🔔 Muhim voqealar
🧹 Keraksiz xabarlarni kamaytirish
🔄 O‘yin holatini avtomatik boshqarish
🛡 Anti-abuse
👤 Bir nechta akkaunt orqali bonuslarni cheksiz olishga qarshi limitlar
👨‍💼 37. Admin panel
➕ Admin qo‘shish
➖ Admin o‘chirish
💵 Pul berish/olish
💎 Olmos berish/olish
👑 VIP berish
🎁 Buyum berish
👤 User ma'lumotlarini ko‘rish
🏆 G‘alaba qo‘shish
🎮 O‘yin sonini o‘zgartirish
🚫 Ban/Unban
📊 Statistikani boshqarish
🎁 Event boshqaruvi
🎟 Promo-kod yaratish
🔥 38. Carleone'ga xos asosiy tizim
Botning markazida:
🎮 Mafia + 🏙 Carleone City + 💰 Iqtisodiyot + 👥 Family + 🏆 Season + 📈 Level + 🎭 Rollar + 🎁 Eventlar
[30.09.2026 18:23] .: Mafia Carleone botining oyin Qoidalari 
👑 Don — Mafia boshlig‘i, Mafia harakatlarini boshqaradi.
🕵️ Komissar — tunda bitta o‘yinchini tekshiradi.
👨‍⚕️ Doktor — tunda bitta o‘yinchini himoya qiladi.
🔫 Sherif — shubhali o‘yinchini tekshiradi.
🧑‍💼 Tinch aholi — maxsus qobiliyati yo‘q, kunduzgi muhokama va ovoz berishda qatnashadi.
💋 Fohisha — bitta o‘yinchining tungi qobiliyatini bloklaydi.
🧙‍♀️ Jodugar — davolash yoki hujum qilish uchun cheklangan imkoniyatlarga ega.
🦹 Maniac — mustaqil tomon, o‘z g‘alaba shartiga ega.
💣 Terrorist — o‘yindan chiqarilganda maxsus ta’sir ko‘rsatadi.
🛡 Bodyguard — tanlagan o‘yinchisini himoya qiladi.
👀 Kuzatuvchi — o‘yinchining kimga harakat qilganini kuzatadi.
🕵️ Detektiv — o‘yinchining tungi faoliyati haqida ma’lumot oladi.
⚖️ Advokat — o‘yinchini tekshiruv natijasidan yashiradi.
🤡 Joker — kunduzgi ovoz berishda o‘yindan chiqarilishga harakat qiladi.
🎯 Ovchi — o‘yindan chiqarilganda boshqa o‘yinchiga qarshi maxsus harakat qiladi.
🧑‍⚖️ Sudya — ovoz berish jarayoniga maxsus ta’sir qiladi.
🧟 Qasoskor — belgilangan shart bajarilganda qarshi harakat qiladi.
🧛 Vampir — alohida tomon bo‘lib, o‘z jamoasining g‘alabasiga harakat qiladi.
🐺 Bo‘ri odam — tunda maxsus hujum qiladi va ayrim tekshiruvlarda yashirinishi mumkin.
👼 Farishta — tanlagan o‘yinchisini himoya qiladi.
🧪 Alkimyogar — maxsus iksirlar yordamida o‘yinga ta’sir qiladi.
💰 O‘g‘ri — boshqa rolning qobiliyatini vaqtincha egallashi mumkin.
🧑‍🔬 Olim — maxsus ma’lumot olishga qodir.
🧙 Sehrgar — boshqa o‘yinchining tungi harakatiga ta’sir qiladi
[30.09.2026 23:23] .: 𝐷𝑖𝑎𝑚𝑜𝑛𝑑 / 𝑃𝑟𝑜:
GROUP MANAGEMENT BOT UCHUN SETTINGS VA PERMISSION SYSTEMNI TO‘LIQ IMPLEMENT QIL.

1\. "/settings"

Guruh admini guruhda:

"/settings"

buyrug‘ini yuborganda bot settings menyusini ochsin.

Bot avval userning admin ekanini tekshirsin.

Agar admin bo‘lmasa:

❌ Sizda guruh sozlamalarini boshqarish huquqi yo‘q.

Agar admin bo‘lsa, quyidagi menyu chiqsin:

⚙️ GROUP SETTINGS

Guruh sozlamalarini qayerda boshqarishni tanlang:

[👥 Shu guruhda ochish]
[💬 Shaxsiy chatda ochish]

\---

2\. "👥 Shu guruhda ochish"

Tugma bosilganda settings menyusi aynan shu guruhning chatida ochilsin.

Masalan:

⚙️ GROUP SETTINGS

👋 Welcome
🚪 Goodbye
🔇 Mute
🚫 Ban
⚠️ Warn
🔗 Anti-Link
🤬 Anti-Badword
🤖 Anti-Spam
🧹 Auto Delete
📝 Rules
📋 Logs

Har bir bo‘lim alohida inline button bo‘lsin.

Masalan:

[👋 Welcome]
[🚪 Goodbye]
[🛡 Moderation]
[🚨 Anti-Spam]
[🔗 Anti-Link]
[🤬 Bad Words]
[📋 Logs]
[⚙️ Other Settings]

\---

3\. "💬 Shaxsiy chatda ochish"

Admin bu tugmani bosganda bot adminning private chatini ochishga yo‘naltirsin.

Private chatda bot:

⚙️ GROUP SETTINGS

Qaysi guruhni sozlamoqchisiz?

[👥 GROUP NAME]

Agar admin bir nechta guruhni boshqarsa, guruhlar ro‘yxati chiqsin.

Admin guruhni tanlagandan keyin aynan o‘sha guruh settingslari ochilsin.

\---

4\. SECURITY

Settingsni ochishdan oldin HAR SAFAR:

1\. User Telegram ID'sini olish.
2\. User aynan shu group admin ekanini tekshirish.
3\. Group ID'ni tekshirish.
4\. Settings boshqa guruhga tegishli emasligini tekshirish.

Private chatdagi settingsda ham admin permission qayta tekshirilsin.

User guruhdan adminlikdan chiqarilsa, eski settings message orqali hech qanday o‘zgarish qila olmasin.

Eski inline buttonlar ishlatilganda:

⚠️ Bu sozlama menyusi eskirgan.

"/settings" ni qayta oching.

\---

5\. BOT PERMISSIONS CHECK

Bot "/settings" ochilganda guruhdagi o‘zining Telegram permissionslarini ham tekshirsin.

Masalan:

Welcome uchun:

\- yangi member eventlarini ko‘rish imkoniyati

Ban uchun:

\- Ban users

Mute uchun:

\- Restrict users

Delete uchun:

\- Delete messages

Pin uchun:

\- Pin messages

Agar botga kerakli permission berilmagan bo‘lsa, tegishli setting ichida aniq ko‘rsatsin:

⚠️ Permission yetishmayapti

Bu funksiyani ishlatish uchun botga quyidagi huquq kerak:

🔴 Restrict members

[⚙️ Bot permissions]
[⬅️ Orqaga]

Bot o‘zida mavjud bo‘lmagan permission bilan funksiyani yoqishga urinmasin.

\---

6\. SETTINGS STATE

Har bir guruhning settingslari boshqa guruhlardan mustaqil saqlansin.

Masalan:

group_id
welcome_enabled
goodbye_enabled
mute_enabled
ban_enabled
warn_enabled
anti_link_enabled
anti_spam_enabled
badword_enabled
logs_enabled

va boshqa barcha konfiguratsiyalar.

Bir guruhdagi "/settings" boshqa guruh sozlamalarini o‘zgartirmasligi kerak.

\---

7\. SETTINGS UI

Har bir setting ON/OFF holatini ko‘rsatib tursin.

Masalan:

👋 WELCOME

Status: 🟢 ON

Yangi a'zo guruhga kirganda avtomatik welcome message yuboriladi.

[🔴 O‘CHIRISH]
[✏️ Xabarni sozlash]
[⬅️ Orqaga]

OFF bo‘lsa:

Status: 🔴 OFF

[🟢 YOQISH]

\---

8\. WELCOME SETTINGS

Welcome bo‘limida:

[🟢 Yoqish/O‘chirish]
[✏️ Xabarni o‘zgartirish]
[👁 Preview]

Placeholderlarni qo‘llab-quvvatla:

"{name}" — foydalanuvchi ismi
"{username}" — username
"{mention}" — clickable mention
"{group}" — guruh nomi

Masalan:

👋 Salom, {mention}!

{group} guruhiga xush kelibsiz! 🎉

\---

9\. GOODBYE SETTINGS

Xuddi Welcome kabi:

[🟢 Yoqish/O‘chirish]
[✏️ Xabarni o‘zgartirish]
[👁 Preview]

Masalan:

🚪 {name} guruhni tark etdi.

\---

10\. ADMIN ACTION VALIDATION

Har bir moderation action bajarilishidan oldin:

\- Moderator adminmi?
\- Moderatorning Telegramdagi real huquqi yetarlimi?
\- Botning kerakli huquqi bormi?
\- Target user admin emasmi?
\- Target user botning o‘zi emasmi?
\- Target user allaqachon ban/mute qilinganmi?
\- Amal aynan shu group uchunmi?

hammasi tekshirilsin.

Agar permission yetishmasa, umumiy:

❌ Error

demasdan, ANIQ sababni ko‘rsat.

Masalan:

❌ Amal bajarilmadi

Botga "Restrict Members" huquqi berilmagan.

Guruh sozlamalaridan botga ushbu huquqni bering.

\---

11\. INLINE NAVIGATION

Barcha settings oynalarida:

[⬅️ Orqaga] [🏠 Bosh menyu]

bo‘lsin.

Yangi message spam qilmasdan imkon qadar mavjud settings message "editMessageText" / "editMessageReplyMarkup" orqali yangilansin.

\---

12\. CALLBACK SECURITY

Har bir callback quyidagilar bilan himoyalansin:

\- user_id
\- group_id
\- settings_session_id
\- action

Boshqa user boshqa adminning settings buttonini bosib sozlamani o‘zgartira olmasin.

Callbacklar eski bo‘lib qolsa, xavfsiz tarzda rad etilsin.

\---

13\. FINAL REQUIREMENT

Settings system production-ready bo‘lsin.

Har bir funksiya:

\- real ishlasin
\- database'da saqlansin
\- restartdan keyin saqlanib qolsin
\- guruhlar bo‘yicha ajratilsin
\- admin permission bilan himoyalansin
\- bot permission yetishmasa aniq sababni ko‘rsatsin
\- group va private settings ikkalasida ham ishlasin.

Placeholder yoki fake button yaratma. Har bir button real backend actionga ulangan bo‘lsin.

Eng foydali funksiya: Custom Role Creator
Admin o‘zi yangi role yaratishi mumkin:
🎭 Create Role
Name: Assassin
Team: Independent
Night Action: Kill
Uses: 2
Target: One player
Win condition: Survive
Shunda botning role systemi keyinchalik cheksiz kengayadi.
[30.09.2026 23:24] .: Owner panelniyam tushunarli qil
[30.09.2026 23:25] .: Kun tun osish va ovoz berish uchun stik emoji qoyib boladigon bosin
[30.09.2026 23:30] .: Keyin ertalab osishda yani ovoz berishda ovoz beryaptimi kimga kop bosa oxrida oshani osamizmi yoqmi chiqadi ha yoq yani like dis like shuni odamla xal qladi osish osmaslikni. Keyin bot hamma narsasi costume emojida bosin keyin oynga qoshilishda shrenga bop tursin oynga qoshlganlar nik name yoki useri yoki botdagi nomi keyin owner panel xamasni boshqara oladigon bosin yaniki pro nik name uchunam costume emoji qoyib bosin
[01.10.2026 0:03] .: auto pin oynga qoshlish uchun auto pin keyin yaniki game qlinsi auto pin qlinadi pin tepada qop ketsa qayta /game qlinadi keyin /exchange  9999 qoysa shuncha daqiqa oynchlar qoshlishni kutadi keyin botga ai ulash yaniki u ozi har bir rol uchun stik yasab beradi