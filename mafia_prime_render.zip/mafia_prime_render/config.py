import os
from dataclasses import dataclass
from dotenv import load_dotenv
load_dotenv()

def _int(name, default):
    try: return int(os.getenv(name, str(default)))
    except ValueError: return default

@dataclass(frozen=True)
class Settings:
    bot_token: str = os.getenv('BOT_TOKEN','')
    owner_id: int = _int('OWNER_ID',0)
    database_url: str = os.getenv('DATABASE_URL','sqlite:///./mafia_prime.db')
    web_base_url: str = os.getenv('WEB_BASE_URL','')
    openai_api_key: str = os.getenv('OPENAI_API_KEY','')
    openai_image_model: str = os.getenv('OPENAI_IMAGE_MODEL','gpt-image-1')
    min_players: int = 4
    max_players: int = 50
    join_time_minutes: int = _int('JOIN_TIME_MINUTES',2)
    night_seconds: int = _int('NIGHT_SECONDS',60)
    discussion_seconds: int = _int('DISCUSSION_SECONDS',120)
    vote_seconds: int = _int('VOTE_SECONDS',30)
    daily_money: int = _int('DAILY_MONEY',1000)
    daily_diamonds: int = _int('DAILY_DIAMONDS',2)
    win_money: int = _int('WIN_MONEY',500)
settings=Settings()
