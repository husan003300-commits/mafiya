# 🎭 Mafia Prime — Render final package

Final modular Telegram Mafia bot based on the supplied specification. Maximum player count is **50**.

## Core
- `/game` lobby, 4–50 players, join timer, auto pin attempt
- `/startgame`, `/cancelgame`
- automatic Night → Day → Discussion → Vote → next Night flow
- role PM actions: Don/Mafia kill, Doctor/Wizard heal, Commissioner/Detective check
- protection resolution, vote tie handling, win-condition engine
- profile, XP, levels, wins/losses
- Money + Diamonds + transfers + transaction records
- daily bonus
- PRO/HERO status with owner grants
- Telegram Stars invoice examples: `/buy_pro`, `/buy_diamonds`
- Owner/Admin/permission system, audit-ready database
- custom roles and custom emoji registry
- group settings, max players fixed at 50, join timer and button style registry
- FastAPI health endpoint and dashboard
- optional AI role image/sticker asset generation
- PostgreSQL or SQLite via `DATABASE_URL`

## Render
Set `BOT_TOKEN`, `OWNER_ID`, and a persistent `DATABASE_URL` (PostgreSQL recommended for persistent production data). Render supplies `PORT`; the web server listens on it.

Start command is already in `render.yaml`: `python -m bot`.

## Owner
`/owner` and commands described there. Owner ID is read from `OWNER_ID`.

## Important
Telegram permissions, group admin status, role, phase and target validity are checked server-side. Buttons are not treated as authorization.

The original supplied specifications are kept under `docs/`.
