from telegram import InlineKeyboardButton,InlineKeyboardMarkup

def kb(rows): return InlineKeyboardMarkup(rows)
def style_text(text,style='primary'):
    return {'success':'✅ ','danger':'❌ ','primary':'🎮 '}.get(style,'🎮 ')+text
