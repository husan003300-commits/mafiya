import asyncio,threading,os
import uvicorn
from telegram import Update
from telegram.ext import Application,CommandHandler,CallbackQueryHandler,MessageHandler,PreCheckoutQueryHandler,filters
from config import settings
from database.db import init_db
from handlers.start import start
from handlers.profile import profile
from handlers.economy import economy,pay
from handlers.bonus import bonus
from handlers.para import para
from handlers.settings import settings_cmd,settings_callback
from handlers.mafia import game,startgame,cancelgame,callback
from handlers.admin import admin,owner,grant,give,add_admin,setperm,customemoji,role_create
from handlers.misc import top,help_cmd,exchange
from handlers.ai_sticker import generate_role_sticker
from handlers.payments import buy_pro,buy_diamonds,precheckout,successful_payment
from web.app import app as web_app

def run_web():uvicorn.run(web_app,host='0.0.0.0',port=int(os.getenv('PORT','10000')),log_level='warning')
async def main():
 if not settings.bot_token:raise RuntimeError('BOT_TOKEN is required')
 init_db();threading.Thread(target=run_web,daemon=True).start()
 app=Application.builder().token(settings.bot_token).build()
 for cmds,fn in [(['start'],start),(['profile','profil'],profile),(['balance','economy'],economy),(['pay'],pay),(['bonus'],bonus),(['para'],para),(['settings'],settings_cmd),(['game'],game),(['startgame'],startgame),(['cancelgame'],cancelgame),(['admin'],admin),(['owner'],owner),(['grant_pro','grant_hero'],grant),(['give'],give),(['add_admin'],add_admin),(['setperm'],setperm),(['customemoji'],customemoji),(['role_create'],role_create),(['top'],top),(['help'],help_cmd),(['exchange','setjoin'],exchange),(['role_sticker','ai_sticker'],generate_role_sticker),(['buy_pro'],buy_pro),(['buy_diamonds'],buy_diamonds)]:app.add_handler(CommandHandler(cmds,fn))
 async def cb(update,context):
  if await settings_callback(update,context):return
  if update.callback_query.data=='noop':return await update.callback_query.answer()
  await callback(update,context)
 app.add_handler(CallbackQueryHandler(cb))
 app.add_handler(PreCheckoutQueryHandler(precheckout))
 app.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT,successful_payment))
 print('Mafia Prime started — max players 50')
 await app.initialize();await app.start();await app.updater.start_polling(allowed_updates=Update.ALL_TYPES)
 await asyncio.Event().wait()
if __name__=='__main__':asyncio.run(main())
