from datetime import datetime, timezone
from database.users import get_or_create

def mention(user):
    name=(user.full_name or "User").replace("<","&lt;").replace(">","&gt;")
    return f'<a href="tg://user?id={user.id}">{name}</a>'

def display(user): return f"@{user.username}" if user.username else user.full_name

def ensure(update): return get_or_create(update.effective_user)
