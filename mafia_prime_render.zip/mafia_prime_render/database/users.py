from datetime import datetime,timezone,timedelta
from database.db import SessionLocal
from database.models import User,Transaction

def get_or_create(tg):
    with SessionLocal() as s:
        u=s.get(User,tg.id)
        if not u: u=User(id=tg.id,username=tg.username,name=tg.full_name or 'User');s.add(u)
        else: u.username=tg.username;u.name=tg.full_name or u.name
        s.commit();s.refresh(u);return u
def get(uid):
    with SessionLocal() as s:return s.get(User,uid)
def add_balance(uid,currency,amount,reason='admin'):
    if currency not in ('money','diamonds') or amount==0:return False
    with SessionLocal() as s:
        u=s.get(User,uid)
        if not u or getattr(u,currency)+amount<0:return False
        old=getattr(u,currency);setattr(u,currency,old+amount);s.add(Transaction(to_user_id=uid,currency=currency,amount=amount,reason=reason));s.commit();return True
def grant_status(uid,status,days):
    if status not in ('pro','hero'):return False
    with SessionLocal() as s:
        u=s.get(User,uid)
        if not u:return False
        now=datetime.now(timezone.utc);attr=status+'_until';cur=getattr(u,attr);base=cur if cur and cur>now else now;setattr(u,attr,base+timedelta(days=days));s.commit();return True
