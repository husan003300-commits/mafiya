from datetime import datetime, timezone
from sqlalchemy import String,Integer,BigInteger,Boolean,DateTime,Text,ForeignKey,UniqueConstraint
from sqlalchemy.orm import Mapped,mapped_column
from database.db import Base

def now(): return datetime.now(timezone.utc)
class User(Base):
    __tablename__='users'
    id: Mapped[int]=mapped_column(BigInteger,primary_key=True); username:Mapped[str|None]=mapped_column(String(255)); name:Mapped[str]=mapped_column(String(255),default='User')
    language:Mapped[str]=mapped_column(String(8),default='uz'); money:Mapped[int]=mapped_column(BigInteger,default=0); diamonds:Mapped[int]=mapped_column(BigInteger,default=0); xp:Mapped[int]=mapped_column(Integer,default=0); level:Mapped[int]=mapped_column(Integer,default=1)
    games:Mapped[int]=mapped_column(Integer,default=0); wins:Mapped[int]=mapped_column(Integer,default=0); losses:Mapped[int]=mapped_column(Integer,default=0); blocked:Mapped[bool]=mapped_column(Boolean,default=False)
    pro_until:Mapped[datetime|None]=mapped_column(DateTime(timezone=True)); hero_until:Mapped[datetime|None]=mapped_column(DateTime(timezone=True)); last_bonus:Mapped[datetime|None]=mapped_column(DateTime(timezone=True)); created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class Group(Base):
    __tablename__='groups'; id:Mapped[int]=mapped_column(BigInteger,primary_key=True); title:Mapped[str]=mapped_column(String(255),default='Group'); owner_id:Mapped[int|None]=mapped_column(BigInteger); premium:Mapped[bool]=mapped_column(Boolean,default=False); blocked:Mapped[bool]=mapped_column(Boolean,default=False); level:Mapped[int]=mapped_column(Integer,default=1); xp:Mapped[int]=mapped_column(Integer,default=0)
class GroupSetting(Base):
    __tablename__='group_settings'; group_id:Mapped[int]=mapped_column(BigInteger,ForeignKey('groups.id'),primary_key=True)
    game_enabled:Mapped[bool]=mapped_column(Boolean,default=True); para_enabled:Mapped[bool]=mapped_column(Boolean,default=True); economy_enabled:Mapped[bool]=mapped_column(Boolean,default=True); bonus_enabled:Mapped[bool]=mapped_column(Boolean,default=True); pro_enabled:Mapped[bool]=mapped_column(Boolean,default=True); hero_enabled:Mapped[bool]=mapped_column(Boolean,default=True)
    max_players:Mapped[int]=mapped_column(Integer,default=50); join_minutes:Mapped[int]=mapped_column(Integer,default=2); night_seconds:Mapped[int]=mapped_column(Integer,default=60); discussion_seconds:Mapped[int]=mapped_column(Integer,default=120); vote_seconds:Mapped[int]=mapped_column(Integer,default=30)
    button_style:Mapped[str]=mapped_column(String(16),default='primary'); emojis:Mapped[str]=mapped_column(Text,default='{}'); templates:Mapped[str]=mapped_column(Text,default='{}'); welcome_enabled:Mapped[bool]=mapped_column(Boolean,default=False); goodbye_enabled:Mapped[bool]=mapped_column(Boolean,default=False); anti_link_enabled:Mapped[bool]=mapped_column(Boolean,default=False)
class Game(Base):
    __tablename__='games'; id:Mapped[int]=mapped_column(Integer,primary_key=True,autoincrement=True); group_id:Mapped[int]=mapped_column(BigInteger,index=True); status:Mapped[str]=mapped_column(String(32),default='lobby'); phase:Mapped[str]=mapped_column(String(32),default='lobby'); day_number:Mapped[int]=mapped_column(Integer,default=0); lobby_message_id:Mapped[int|None]=mapped_column(BigInteger); pin_message_id:Mapped[int|None]=mapped_column(BigInteger); join_deadline:Mapped[datetime|None]=mapped_column(DateTime(timezone=True)); created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now); winner:Mapped[str|None]=mapped_column(String(32))
class GamePlayer(Base):
    __tablename__='game_players'; __table_args__=(UniqueConstraint('game_id','user_id'),); id:Mapped[int]=mapped_column(Integer,primary_key=True,autoincrement=True); game_id:Mapped[int]=mapped_column(ForeignKey('games.id'),index=True); user_id:Mapped[int]=mapped_column(BigInteger,index=True); display_name:Mapped[str]=mapped_column(String(255)); role:Mapped[str|None]=mapped_column(String(64)); role_key:Mapped[str|None]=mapped_column(String(64)); team:Mapped[str|None]=mapped_column(String(64)); alive:Mapped[bool]=mapped_column(Boolean,default=True); action_used:Mapped[bool]=mapped_column(Boolean,default=False)
class GameAction(Base):
    __tablename__='game_actions'; id:Mapped[int]=mapped_column(Integer,primary_key=True,autoincrement=True); game_id:Mapped[int]=mapped_column(ForeignKey('games.id'),index=True); actor_id:Mapped[int]=mapped_column(BigInteger); target_id:Mapped[int|None]=mapped_column(BigInteger); action:Mapped[str]=mapped_column(String(32)); day:Mapped[int]=mapped_column(Integer,default=0); phase:Mapped[str]=mapped_column(String(32)); created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class Vote(Base):
    __tablename__='votes'; id:Mapped[int]=mapped_column(Integer,primary_key=True,autoincrement=True); game_id:Mapped[int]=mapped_column(ForeignKey('games.id')); voter_id:Mapped[int]=mapped_column(BigInteger); target_id:Mapped[int]=mapped_column(BigInteger); kind:Mapped[str]=mapped_column(String(32),default='eliminate'); day:Mapped[int]=mapped_column(Integer,default=0); __table_args__=(UniqueConstraint('game_id','voter_id','kind','day'),)
class Transaction(Base):
    __tablename__='transactions'; id:Mapped[int]=mapped_column(Integer,primary_key=True,autoincrement=True); from_user_id:Mapped[int|None]=mapped_column(BigInteger); to_user_id:Mapped[int|None]=mapped_column(BigInteger); currency:Mapped[str]=mapped_column(String(16)); amount:Mapped[int]=mapped_column(BigInteger); reason:Mapped[str]=mapped_column(String(255)); created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class Admin(Base):
    __tablename__='admins'; user_id:Mapped[int]=mapped_column(BigInteger,primary_key=True); level:Mapped[str]=mapped_column(String(32),default='moderator'); permissions:Mapped[str]=mapped_column(Text,default='{}')
class Para(Base):
    __tablename__='paras'; user_id:Mapped[int]=mapped_column(BigInteger,primary_key=True); partner_id:Mapped[int]=mapped_column(BigInteger,unique=True)
class CustomRole(Base):
    __tablename__='custom_roles'; id:Mapped[int]=mapped_column(Integer,primary_key=True,autoincrement=True); owner_id:Mapped[int]=mapped_column(BigInteger); name:Mapped[str]=mapped_column(String(64)); team:Mapped[str]=mapped_column(String(32)); night_action:Mapped[str]=mapped_column(String(32)); uses:Mapped[int]=mapped_column(Integer,default=1); target:Mapped[str]=mapped_column(String(32),default='one'); win_condition:Mapped[str]=mapped_column(String(255),default='survive')
class CustomEmoji(Base):
    __tablename__='custom_emojis'; id:Mapped[int]=mapped_column(Integer,primary_key=True,autoincrement=True); owner_id:Mapped[int]=mapped_column(BigInteger); key:Mapped[str]=mapped_column(String(64)); value:Mapped[str]=mapped_column(String(255)); __table_args__=(UniqueConstraint('owner_id','key'),)
class AuditLog(Base):
    __tablename__='audit_logs'; id:Mapped[int]=mapped_column(Integer,primary_key=True,autoincrement=True); actor_id:Mapped[int]=mapped_column(BigInteger); action:Mapped[str]=mapped_column(String(128)); target:Mapped[str|None]=mapped_column(String(255)); result:Mapped[str]=mapped_column(String(255),default='ok'); created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class Achievement(Base):
    __tablename__='achievements'; id:Mapped[int]=mapped_column(Integer,primary_key=True,autoincrement=True); user_id:Mapped[int]=mapped_column(BigInteger,index=True); code:Mapped[str]=mapped_column(String(64)); created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now); __table_args__=(UniqueConstraint('user_id','code'),)
